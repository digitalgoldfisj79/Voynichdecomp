#!/usr/bin/env python3
import sys, os, json, math, time, collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data/voynich_workingset_v01')
import workingset as w
sys.path.insert(0,'/mnt/data/voynich_regional_v01')
from regional import RegionalModel, RegionalState, choose_lambda, MU
s2=w.s2
METRICS=list(s2.METRICS)
SOURCE_LAM={0:.03,1:.03,2:.03,3:.02,4:.03}
R=64

# Prospective T0b seed namespaces, disjoint from T0 and from each other.
STAGE_CODE={'construction':11,'calibration':12,'validation':13,'control':20,'voynich':30}
CONTROL_CODE={'gross_family_shuffle':1,'gross_page_shuffle':2,'near_refractory':3,'near_line_reset':4,'near_opener':5,'near_family_persistence':6}

# Frozen omitted-mechanism amplitudes. These are never tuned on T0b outcomes.
REFRACTORY_RHO=0.04          # inherited from prior refractory synthetic source
OPENER_OMEGA=0.05            # deliberately small fixed line-opener mixture
FAMILY_PERSIST_RHO=0.04      # same small-capacity scale as refractory control


def seed(stage,trial,fold,slot=0,control=None):
    sc=STAGE_CODE[stage]
    cc=CONTROL_CODE.get(control,0) if control else 0
    return int(810_000_000 + sc*10_000_000 + cc*1_000_000 + trial*10_000 + fold*100 + slot)


def source_models(kind='g0'):
    out={}
    for f in range(5):
        tr,te=w.fold_data(f)
        base=RegionalModel(tr,f,lam=SOURCE_LAM[f])
        out[f]=(base,tr,te)
    return out


def _weighted_choice(vals,weights,rng):
    if not vals:return None
    ww=np.asarray(weights,float); z=ww.sum()
    if z<=0:return None
    return vals[int(rng.choice(len(vals),p=ww/z))]


def generate_refractory(base,skeleton,rng):
    """G0 plus exact-token refractory cache: lag1 excluded; d2-5 weight1; d6-64 weight.25; rho=.04."""
    st=RegionalState(base.base.train_vocab); out=[]
    for r0 in skeleton:
        r=dict(r0); st.boundary(r)
        seq=st.page_seq; vals=[]; ww=[]
        n=len(seq)
        for d in range(2,min(R,n)+1):
            t=seq[-d]
            if t in base.base.train_vocab:
                vals.append(t); ww.append(1.0 if d<=5 else .25)
        use=bool(vals) and rng.random()<REFRACTORY_RHO
        if use:
            t=_weighted_choice(vals,ww,rng)
        else:
            # Draw one event from G0's exact frozen mixture without target access.
            lam=base.lam; mu=base.mu
            hasr=bool(base.region_candidates(st)); hasn=bool(base.near_candidates(st)); wb=1-lam-mu
            if not hasr:wb+=lam;lam=0.
            if not hasn:wb+=mu;mu=0.
            z=wb+lam+mu; src=int(rng.choice(3,p=np.array([wb,lam,mu])/z))
            if src==1:t=base.sample_region(st,rng)
            elif src==2:t=base.sample_near(st,rng)
            else:t=base._draw_core(st,r,rng,'full')
            if t is None:t=base._draw_core(st,r,rng,'full')
        r['token']=t; r['family']=s2.famof(t); out.append(r); st.update(r,t)
    return out


class LineResetState(RegionalState):
    def boundary(self,r):
        old=(self.page,self.line)
        super().boundary(r)
        if (r['page'],r['line'])!=old:
            self.page_seq=[]


def generate_line_reset(base,skeleton,rng):
    """G0 architecture but R64 memory resets at every physical line rather than page."""
    st=LineResetState(base.base.train_vocab); out=[]
    for r0 in skeleton:
        r=dict(r0); st.boundary(r)
        lam=base.lam; mu=base.mu
        hasr=bool(base.region_candidates(st)); hasn=bool(base.near_candidates(st)); wb=1-lam-mu
        if not hasr:wb+=lam;lam=0.
        if not hasn:wb+=mu;mu=0.
        z=wb+lam+mu; src=int(rng.choice(3,p=np.array([wb,lam,mu])/z))
        if src==1:t=base.sample_region(st,rng)
        elif src==2:t=base.sample_near(st,rng)
        else:t=base._draw_core(st,r,rng,'full')
        if t is None:t=base._draw_core(st,r,rng,'full')
        r['token']=t;r['family']=s2.famof(t);out.append(r);st.update(r,t)
    return out


def opener_tables(train):
    """Training-only token tables for line-relative opener classes first/second/rest, pooled section×hand then global."""
    tab=collections.defaultdict(collections.Counter)
    for r in train:
        cls=0 if r['pos']==0 else (1 if r['pos']==1 else 2)
        for key in [(r['section'],r['hand'],cls),('__SEC__',r['section'],cls),('__GLOBAL__','__GLOBAL__',cls)]:
            tab[key][r['token']]+=1
    return tab


def generate_opener(base,train,skeleton,rng):
    """G0 plus small training-only line-opener token mixture at positions 0/1 (omega=.05)."""
    tab=opener_tables(train); st=RegionalState(base.base.train_vocab);out=[]
    for r0 in skeleton:
        r=dict(r0);st.boundary(r)
        isopen=r['pos'] in (0,1)
        if isopen and rng.random()<OPENER_OMEGA:
            cls=int(r['pos']); c=tab.get((r['section'],r['hand'],cls)) or tab.get(('__SEC__',r['section'],cls)) or tab[('__GLOBAL__','__GLOBAL__',cls)]
            vals=list(c); ww=[c[x] for x in vals]; t=_weighted_choice(vals,ww,rng)
        else:
            lam=base.lam;mu=base.mu;hasr=bool(base.region_candidates(st));hasn=bool(base.near_candidates(st));wb=1-lam-mu
            if not hasr:wb+=lam;lam=0.
            if not hasn:wb+=mu;mu=0.
            z=wb+lam+mu;src=int(rng.choice(3,p=np.array([wb,lam,mu])/z))
            if src==1:t=base.sample_region(st,rng)
            elif src==2:t=base.sample_near(st,rng)
            else:t=base._draw_core(st,r,rng,'full')
            if t is None:t=base._draw_core(st,r,rng,'full')
        r['token']=t;r['family']=s2.famof(t);out.append(r);st.update(r,t)
    return out


def generate_family_persistence(base,skeleton,rng):
    """G0 plus rho=.04 family-level page cache at lags2..64; token drawn from training vocabulary within selected family."""
    st=RegionalState(base.base.train_vocab);out=[]
    fam_vocab=collections.defaultdict(list)
    for t in base.base.train_vocab:fam_vocab[s2.famof(t)].append(t)
    for r0 in skeleton:
        r=dict(r0);st.boundary(r); seq=st.page_seq; fams=[];ww=[]
        n=len(seq)
        for d in range(2,min(R,n)+1):
            f=s2.famof(seq[-d]);
            if fam_vocab.get(f):fams.append(f);ww.append(1.0)
        if fams and rng.random()<FAMILY_PERSIST_RHO:
            f=_weighted_choice(fams,ww,rng); vals=fam_vocab[f]; weights=[base.gtok.get(t,0)+1 for t in vals];t=_weighted_choice(vals,weights,rng)
        else:
            lam=base.lam;mu=base.mu;hasr=bool(base.region_candidates(st));hasn=bool(base.near_candidates(st));wb=1-lam-mu
            if not hasr:wb+=lam;lam=0.
            if not hasn:wb+=mu;mu=0.
            z=wb+lam+mu;src=int(rng.choice(3,p=np.array([wb,lam,mu])/z))
            if src==1:t=base.sample_region(st,rng)
            elif src==2:t=base.sample_near(st,rng)
            else:t=base._draw_core(st,r,rng,'full')
            if t is None:t=base._draw_core(st,r,rng,'full')
        r['token']=t;r['family']=s2.famof(t);out.append(r);st.update(r,t)
    return out


def shuffle_rows(rows,kind,rng):
    out=[dict(r) for r in rows]
    if kind=='gross_family_shuffle':
        groups=collections.defaultdict(list)
        for i,r in enumerate(out):groups[(r['page'],r['family'])].append(i)
        for ids in groups.values():
            toks=[out[i]['token'] for i in ids]; rng.shuffle(toks)
            for i,t in zip(ids,toks):out[i]['token']=t;out[i]['family']=s2.famof(t)
    elif kind=='gross_page_shuffle':
        groups=collections.defaultdict(list)
        for i,r in enumerate(out):groups[r['page']].append(i)
        for ids in groups.values():
            toks=[out[i]['token'] for i in ids];rng.shuffle(toks)
            for i,t in zip(ids,toks):out[i]['token']=t;out[i]['family']=s2.famof(t)
    else:raise ValueError(kind)
    return out


def hidden_generate(base,orig,stage,trial,fold,slot,control=None,train_for_opener=None):
    rng=np.random.default_rng(seed(stage,trial,fold,slot,control))
    if control in (None,'g0'):
        return base.generate(orig,seed(stage,trial,fold,slot,control),'full')
    if control=='near_refractory':return generate_refractory(base,orig,rng)
    if control=='near_line_reset':return generate_line_reset(base,orig,rng)
    if control=='near_opener':return generate_opener(base,train_for_opener,orig,rng)
    if control=='near_family_persistence':return generate_family_persistence(base,orig,rng)
    if control in ('gross_family_shuffle','gross_page_shuffle'):
        g=base.generate(orig,seed(stage,trial,fold,slot,control),'full')
        return shuffle_rows(g,control,rng)
    raise ValueError(control)


def one_fold(src_tuple,stage,trial,f,control=None,real_voynich=False):
    src,orig_tr,orig_te=src_tuple
    if real_voynich:
        syn_tr=orig_tr; syn_te=orig_te
    else:
        # hidden source for both train and heldout. For opener, source tables are fit only on original source training,
        # which is external to the synthetic analysis fit and frozen before target generation.
        syn_tr=hidden_generate(src,orig_tr,stage,trial,f,11,control,train_for_opener=orig_tr)
        syn_te=hidden_generate(src,orig_te,stage,trial,f,29,control,train_for_opener=orig_tr)
    lam,inner=choose_lambda(syn_tr,f)
    fit=RegionalModel(syn_tr,f,lam=lam)
    ref=set(fit.base.train_vocab)
    target=s2.metrics(syn_te,ref)
    arr=[]
    for k in range(8):
        g=fit.generate(syn_te,seed(stage,trial,f,40+k,control),'full')
        arr.append([s2.metrics(g,ref)[m] for m in METRICS])
    arr=np.asarray(arr,float);gm=arr.mean(axis=0);tv=np.asarray([target[m] for m in METRICS],float);d=gm-tv
    pfull=fit.score(syn_te,'full');pnoreg=fit.score(syn_te,'noregion');pnoord=fit.score(syn_te,'noorder')
    return {'fold':f,'selected_lambda':float(lam),'source_lambda':SOURCE_LAM[f],
            'd':[float(x) for x in d], 'target':[float(x) for x in tv], 'gen_mean':[float(x) for x in gm],
            'gain_region':float(pnoreg-pfull),'gain_order':float(pnoord-pfull)}


def run_trial(stage,trial,control=None,real_voynich=False):
    srcs=source_models();t=time.time();folds=[one_fold(srcs[f],stage,trial,f,control,real_voynich) for f in range(5)]
    return {'stage':stage,'trial':trial,'control':control,'real_voynich':real_voynich,'elapsed_sec':time.time()-t,'metrics':METRICS,'folds':folds}


def qa():
    assert len(w.ROWS)==34087 and len(METRICS)==20 and sorted(set(w.FOLDS.values()))==[0,1,2,3,4]
    srcs=source_models();m,tr,te=srcs[0]
    # target-token oracle for base generation
    sk=[dict(x) for x in te[:300]];sk2=[dict(x,token='zzzzzz',family='z|z|56') for x in sk]
    assert [r['token'] for r in m.generate(sk,991991,'full')]==[r['token'] for r in m.generate(sk2,991991,'full')]
    return {'rows':len(w.ROWS),'metrics':METRICS,'target_token_oracle':True,'source_lam':SOURCE_LAM,
            'controls':CONTROL_CODE,'amplitudes':{'refractory_rho':REFRACTORY_RHO,'opener_omega':OPENER_OMEGA,'family_persist_rho':FAMILY_PERSIST_RHO}}

if __name__=='__main__':
    # Usage: t0b_runner.py STAGE START STOP [CONTROL]
    stage=sys.argv[1]; start=int(sys.argv[2]); stop=int(sys.argv[3]); control=sys.argv[4] if len(sys.argv)>4 else None
    if stage not in ('construction','calibration','validation','control','voynich'):raise SystemExit('bad stage')
    q=qa();print('T0BQA='+json.dumps(q,separators=(',',':')),flush=True)
    if stage=='voynich':
        r=run_trial('voynich',0,None,real_voynich=True);print('T0BTRIAL='+json.dumps(r,separators=(',',':')),flush=True);raise SystemExit
    for trial in range(start,stop):
        r=run_trial(stage,trial,control=control);print('T0BTRIAL='+json.dumps(r,separators=(',',':')),flush=True)
