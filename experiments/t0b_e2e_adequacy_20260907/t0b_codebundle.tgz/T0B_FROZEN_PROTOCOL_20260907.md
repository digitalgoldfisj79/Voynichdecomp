# T0b — End-to-End Conditional Surface Adequacy Calibration
Date frozen: 2026-09-07
Status at freeze: TARGET SEALED; NO T0b construction outcomes observed.

## Question
Can a prospectively calibrated end-to-end adequacy instrument (a) accept the frozen G0 conditional surface family when G0 is true and (b) reject deliberately misspecified source families, before it is applied once to Voynich?

G0 = frozen WorkingSetV2 + regional R64 family, five inherited physical-bifolium folds. The test is conditional on the inherited manuscript skeleton/metadata; it is not an autonomous manuscript generator test.

## Data splits and hard separation
- Construction: 60 independent G0 trials, trial ids 0..59, seed namespace 11.
- Threshold calibration: 50 independent G0 trials, ids 0..49, namespace 12.
- Untouched validation: 50 independent G0 trials, ids 0..49, namespace 13.
- Controls (only if validation passes): 40 trials per source, namespace 20 with source-specific namespaces.
- Voynich: opened once only if validation and power gates pass, namespace 30 for forward simulation.
No trial moves between sets. Any change to construction code invalidates threshold/validation and requires regeneration.

## Per-fold end-to-end discrepancy
For every trial/fold: generate fresh source training and heldout realizations on the inherited skeleton; reselect regional lambda by the inherited inner-CV grid; refit RegionalModel from synthetic training only; compute heldout target metrics; generate exactly 8 forward simulations; record d = mean_generated_20vector - heldout_source_20vector.
All original 20 Stage-2 metrics remain initially admitted. No T0-failing metric is deleted after outcome inspection.

## Construction envelope
For each physical fold separately, using only the 60 construction vectors:
1. Metric j is degenerate only if empirical SD <= 1e-12; degenerate coordinates are excluded prospectively and reported.
2. Estimate mean vector and Ledoit-Wolf covariance on active coordinates.
3. For each vector define Mahalanobis M and max-coordinate X=max_j |(d_j-mu_j)/sd_j|.
4. Store the construction empirical distributions of M and X.
For a new fold vector, define p_M=(1 + number of construction M >= observed M)/(n+1), likewise p_X. Fold anomaly A=max(-ln p_M,-ln p_X).
For a five-fold manuscript, T is the second-worst fold anomaly (4th order statistic of five), preserving the historical tolerance of one aberrant physical fold.

## Threshold calibration
Apply the frozen construction envelope to 50 calibration trials. Split-conformal 95% threshold q is the ceil((n+1)*0.95)-th ordered calibration T (49th of 50). This threshold is frozen before validation.

## Known-source validation gate
Apply q unchanged to 50 untouched G0 validation trials. PASS requires >=46/50 accepted (T<=q). Wilson interval is reported. If this gate fails: STOP; controls and Voynich remain sealed.

## Omitted-mechanism / misspecification controls
Run only after validation PASS. Analysis model remains ordinary G0; only hidden source changes. 40 independent trials each:
- gross_family_shuffle: G0 then within-page×family token permutation.
- gross_page_shuffle: G0 then within-page token permutation.
- near_refractory: G0 + exact-token refractory cache, lag1 excluded, d2-5 weight1, d6-64 weight0.25, rho=0.04 (inherited prior synthetic-source amplitude).
- near_line_reset: G0 architecture with regional R64 page cache reset at each physical line. This prospectively replaces the originally planned paragraph-reset control because the frozen event table has no paragraph identifier; no synthetic paragraph boundaries are invented.
- near_opener: G0 + training-only line-relative token opener at pos0/pos1, fixed mixture omega=0.05.
- near_family_persistence: G0 + family-level page-cache source at lags2..64, fixed rho=0.04.
Amplitudes/mechanics are frozen before construction outcomes and are not tuned if power is low.

Power gates:
- each gross control: >=95% rejection.
- near controls: at least 3 of 4 must have >=80% rejection AND mean-T separation from untouched G0 validation >=2 validation-null SD.
If a near-control effect/nullSD <2, headline: THE METRIC DOES NOT RESOLVE THAT DEPARTURE.
If power gates fail: instrument is NON-DISCRIMINATING; Voynich remains sealed.

## Voynich opening
Only after validation + power PASS. Fit/select G0 on the real inherited five folds; run exactly 8 frozen forward simulations; compute the 20-vector discrepancies, fold A scores and manuscript T. No threshold/refit/control amendment is allowed after target opening.
Outcomes:
- T<=q: G0 NOT REJECTED (conditional surface compatibility only; not proof of asemicity, meaninglessness, or historical mechanism).
- T>q: G0 REJECTED by a known-source-calibrated, power-validated instrument.

## Sensitivity (non-rescue)
After the primary result only: report alternate forward seeds / 16-simulation stability and leave-one-metric-family-out diagnostics. They cannot rescue a failed primary gate or reverse the frozen target decision.

## Leakage / audit assertions
- Generation must not access target token/family; oracle perturbation assertion retained.
- Model selection sees synthetic training only.
- Construction/calibration/validation/control seed namespaces are disjoint.
- Threshold code never receives Voynich data.
- T0 remains permanently recorded as a failed prior instrument; T0b is separately named.
