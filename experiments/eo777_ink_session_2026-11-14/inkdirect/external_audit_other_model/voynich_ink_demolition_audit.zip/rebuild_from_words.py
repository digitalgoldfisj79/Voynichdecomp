"""Clean-room reproducibility recipe for the word -> page -> sheet stage.

Inputs MUST be acquired independently from the documented public primary files.
This script was prepared after an independent JS implementation ran on the original
11,309 word records. It was not used to generate the attached checkpoint CSV.

Usage:
  python rebuild_from_words.py words_y2014.csv.gz golf-v21-assignments.csv physical_map.csv

No import or execution of analysis6.py or spatial/common.py.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

if len(sys.argv)!=4:
    raise SystemExit(__doc__)
wordfile,golffile,physicalfile=map(Path,sys.argv[1:])
w=pd.read_csv(wordfile)
g=pd.read_csv(golffile)
pm=pd.read_csv(physicalfile)
w=w[(w.darkness>0)&(w.peak>0)&w.sigma_hat.notna()&(w.width_px>0)].copy()
assert len(w)>10000
chars=sorted(set(''.join(w.word.astype(str))))
X=np.empty((len(w),1+len(chars)))
X[:,0]=1.0
for j,c in enumerate(chars,1):
    X[:,j]=w.word.astype(str).str.count(__import__('re').escape(c))

def resid(y,model):
    return np.asarray(y)-model@np.linalg.lstsq(model,y,rcond=None)[0]

w['D_net']=resid(np.log(w.darkness.to_numpy()),X)
w['D_adj']=resid(w.D_net.to_numpy(),np.c_[np.ones(len(w)),w.sigma_hat.to_numpy(),np.log(w.width_px.to_numpy())])
w['P_net']=resid(np.log(w.peak.to_numpy()),X)
w=w[w.page.isin(w.groupby('page').page.size().loc[lambda x:x>=20].index)]
p=w.groupby('page').agg(d_net=('D_net','mean'),d_adj=('D_adj','mean'),peak=('P_net','mean'),sigma=('sigma_hat','mean'),B=('B','mean'))
p['sheet']=pm.set_index('folio').loc[p.index,'bifolium'].to_numpy()
sheet=p.groupby('sheet').agg({'d_net':'mean','d_adj':'mean','peak':'mean','sigma':'mean','B':'mean'})
sheet['pages']=p.groupby('sheet').size()

# Independent ordered-majority field (tied categories resolved lexicographically).
def mode(series):
    s=series.dropna().astype(str)
    return s.value_counts().index[0] if len(s) else 'NA'
meta=pm.groupby('bifolium').agg(section=('section',mode),hand=('hand',mode),quire=('quire','first'),first_leaf=('leaf','min'))
meta['section_hand']=meta.section+'|'+meta.hand
rank=g.groupby('sheet').bifolium_path_rank.first().dropna().astype(int)
sheet=sheet.join(meta).join(rank.rename('rank'),how='inner').sort_values('rank')
assert len(sheet)==48,('unexpected measurable sheet count',len(sheet))

g['weighted_vote']=np.where(g.text_kind=='para',pd.to_numeric(g.readable_words,errors='coerce').fillna(0),0)
votes=g.groupby(['sheet','assignment_code']).weighted_vote.sum().sort_values(ascending=False).reset_index()
cluster=votes.drop_duplicates('sheet').set_index('sheet').assignment_code
sheet['cluster']=cluster.reindex(sheet.index)
print('words',len(w),'pages',len(p),'sheets',len(sheet),'Path1 neighbour D_net',np.abs(np.diff(sheet.d_net)).mean())
print('Binding neighbour D_net',np.abs(np.diff(sheet.sort_values('first_leaf').d_net)).mean())
print(sheet[['rank','d_net','d_adj','sigma','B','cluster','section_hand','quire']].to_csv())
