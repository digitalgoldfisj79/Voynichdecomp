"""Control-fairness check: does any covariate sharing focus's r with darkness erase Path1?"""
import numpy as np, pandas as pd, pickle, os, tempfile, json
from pathlib import Path
P=Path(__file__).parent
D=pd.read_csv(P/'independent_sheet_values_with_controls.csv',dtype={'cluster':str}).sort_values('rank').reset_index(drop=True)
y=D.d_net.to_numpy(); n=len(y); yn=(y-y.mean())/y.std(); sig=D.sigma.to_numpy(); r=float(np.corrcoef(y,sig)[0,1]);
rng=np.random.default_rng(114011)
ord=np.arange(n)
groups=[np.flatnonzero(D.section_hand.to_numpy()==g) for g in sorted(D.section_hand.unique())]
npers=4000
perms=np.tile(ord,(npers,1))
for j in range(npers):
    for group in groups:
        perms[j,group]=rng.permutation(perms[j,group])

def eval_v(v):
    obs=np.mean(np.abs(np.diff(v)))
    null=np.mean(np.abs(np.diff(v[perms],axis=1)),axis=1)
    return ((null.mean()-obs)/null.std(), null.mean()-obs, null.std())

def residual(y,x):
    X=np.c_[np.ones(n),x]
    return y-X@np.linalg.lstsq(X,y,rcond=None)[0]

num=500
z=[]
for j in range(num):
    e=rng.normal(size=n);e-=e.mean();e=e-(e@yn)/(yn@yn)*yn;e/=e.std()
    x=r*yn+np.sqrt(1-r*r)*e
    z.append(eval_v(residual(y,x))[0])
real=eval_v(residual(y,sig))
res={'focus_r':r, 'actual_focus_z':real[0], 'actual_focus_effect':real[1], 'actual_focus_null_sd':real[2], 'simulations':num, 'matched_correlation_random_covariate_z_median':float(np.median(z)), 'fraction_below_two_sigma':float(np.mean(np.array(z)<2)), 'fraction_below_one_sigma':float(np.mean(np.array(z)<1)), 'actual_focus_z_percentile_among_synthetic':float(np.mean(np.array(z)<=real[0])), 'z_quantiles_05_50_95':np.quantile(z,[.05,.5,.95]).tolist()}
with tempfile.NamedTemporaryFile(dir=P,suffix='.pkl',delete=False) as f:
    pickle.dump({'result':res,'z':z},f,protocol=pickle.HIGHEST_PROTOCOL);t=f.name
os.replace(t,P/'03_focus_overcontrol_calibration.pkl')
(P/'focus_overcontrol_calibration.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2))
