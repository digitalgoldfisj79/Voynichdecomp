"""Independent aggregation-level demolition of the 2014 Path1 ink claim.

Input CSV independently re-derived from original words_y2014.csv.gz via
an independent JS GZIP decoder and ordinary least squares glyph regression.
No use of analysis6.py outputs in these statistical calculations.
"""
import json, pickle, tempfile, os
from pathlib import Path
import numpy as np
import pandas as pd

OUT=Path(__file__).parent
D=pd.read_csv(OUT/'independent_sheet_values.csv',dtype={'cluster':str}).sort_values('rank').reset_index(drop=True)
assert len(D)==48 and len(set(D['sheet']))==48 and set(D['rank'])==set(range(1,51))-{28,29}
D['binding_first_leaf']=D.sheet.str.extract(r'^\w+:(\d+)')[0].astype(int)
D['section']=D.section_hand.str.split('|',regex=False).str[0]
D['joint']=D.section_hand+'|'+D.cluster
X=np.c_[np.ones(len(D)),D.sigma]
D['focus_res']=D.d_net-X@np.linalg.lstsq(X,D.d_net,rcond=None)[0]
Xboth=np.c_[np.ones(len(D)),D.sigma,D.B]
D['focus_B_res']=D.d_net-Xboth@np.linalg.lstsq(Xboth,D.d_net,rcond=None)[0]
Xstratum=np.c_[np.ones(len(D)),D.sigma,pd.get_dummies(D.section_hand,drop_first=True,dtype=float).values]
D['focus_within_strata_res']=D.d_net-Xstratum@np.linalg.lstsq(Xstratum,D.d_net,rcond=None)[0]
paths={'path1':D.index.to_numpy(),'binding':D.sort_values('binding_first_leaf',kind='stable').index.to_numpy()}


def atomic_pickle(obj, name):
    with tempfile.NamedTemporaryFile(dir=OUT, prefix='.atomic_', suffix='.pkl',delete=False) as f:
        pickle.dump(obj,f,protocol=pickle.HIGHEST_PROTOCOL)
        tmp=f.name
    os.replace(tmp,OUT/name)

def test(order, v, group='section_hand', n=30000, seed=20261114):
    vals=D[v].to_numpy(float); order=np.asarray(order)
    labels=D[group].to_numpy()[order] if group!='all' else np.array(['all']*len(order))
    strata=[np.where(labels==g)[0] for g in sorted(set(labels))]
    obs=np.abs(np.diff(vals[order])).mean()
    r=np.random.default_rng(seed); null=np.empty(n)
    for j in range(n):
        o=order.copy()
        for positions in strata:
            o[positions]=r.permutation(o[positions])
        null[j]=np.abs(np.diff(vals[o])).mean()
    mu=null.mean(); sd=null.std(ddof=0)
    return {'obs':float(obs),'null_mean':float(mu),'null_sd':float(sd),'effect':float(mu-obs),'z':float((mu-obs)/sd),'one_sided_p':float((1+(null<=obs).sum())/(n+1)),'group_sizes':sorted([len(g) for g in strata],reverse=True),'perm_n':n}

res={'meta':{'number_of_word_records':11309,'measured_sheets':48,'blank_rank_sheets':['I:67-68','J:69-70'], 'retraction_registry': ['RETRACT as physical-order evidence pending independent image/ink replication: Path1 smoothness vanishes under text-cluster matching and sheet-focus adjustment','RETRACT Path1-specific interpretation: alternative text-derived paths show similar smoothness','RETRACT assertion section×hand control rules out textual grouping: it omits eo777 cluster']}}
res['main']={name:test(ord,'d_net') for name,ord in paths.items()}
res['cluster_matched']={name:test(ord,'d_net','joint') for name,ord in paths.items()}
res['focus']={k:test(paths['path1'],k) for k in ['d_adj','focus_res','focus_B_res','focus_within_strata_res','sigma','B','peak']}
res['focus_cluster_matched']={k:test(paths['path1'],k,'joint') for k in ['d_adj','focus_res','focus_within_strata_res']}
res['strata_more_restrictive']={g:test(paths['path1'],'d_net',g) for g in ['section','quire']}
D['section_hand_quire']=D.section_hand+'|'+D.quire
res['strata_more_restrictive']['section_hand_quire']=test(paths['path1'],'d_net','section_hand_quire')

H=D.index[D.section_hand=='H|1'].to_numpy()
res['H1']={g:test(H,'d_net',g) for g in ['all','joint']}
# Guard against spurious cross-group effect, share both a nominal contrast and
# a familywise maximum over all 3 pairs of sizeable herbal hand-1 clusters.
M=D.loc[D.section_hand=='H|1'].query('cluster in ["1a","1b","1.5a"]').copy()
y=M.d_net.to_numpy(); sig=M.sigma.to_numpy(); cluster=M.cluster.to_numpy()
assert [sum(cluster==g) for g in ['1a','1b','1.5a']]==[10,8,5]
R=np.random.default_rng(12480321)
N=50000
pair_names=[('1a','1b'),('1a','1.5a'),('1b','1.5a')]
obs_pair={a+'--'+b:abs(y[cluster==a].mean()-y[cluster==b].mean()) for a,b in pair_names}
obs=obs_pair['1a--1b']
null1=np.empty(N);nullmax=np.empty(N);nullsigned=np.empty(N)
for i in range(N):
    shuffled=R.permutation(cluster)
    centers={g:y[shuffled==g].mean() for g in ['1a','1b','1.5a']}
    nullsigned[i]=centers['1b']-centers['1a']
    null1[i]=abs(centers['1a']-centers['1b'])
    nullmax[i]=max(abs(centers[a]-centers[b]) for a,b in pair_names)
# Additional global and H1-only focus controls
x=np.c_[np.ones(len(M)),sig]
yh=y-x@np.linalg.lstsq(x,y,rcond=None)[0]
fh=abs(yh[cluster=='1b'].mean()-yh[cluster=='1a'].mean())
nullfh=np.empty(N)
R2=np.random.default_rng(41221)
for i in range(N):
    s=R2.permutation(cluster)
    nullfh[i]=abs(yh[s=='1b'].mean()-yh[s=='1a'].mean())
res['H1_cluster_pair']={'n':len(M),'sizes':{g:int(sum(cluster==g)) for g in ['1a','1b','1.5a']},
                         'observed_1b_minus_1a':float(y[cluster=='1b'].mean()-y[cluster=='1a'].mean()),
                         'two_sided_null_mean_abs':float(null1.mean()),'two_sided_null_sd_abs':float(null1.std()),
                         'signed_null_sd':float(np.std([y[R.permutation(cluster)=='1b'].mean()-y[R.permutation(cluster)=='1a'].mean() for _ in range(2000)])),
                         'uncorrected_p':float((1+np.sum(null1>=obs))/(N+1)),
                         'FWER_3pairs_p':float((1+np.sum(nullmax>=obs))/(N+1)),
                         'focus_corrected_H1_contrast_abs':float(fh),
                         'focus_corrected_H1_abs_null_mean':float(nullfh.mean()),
                         'focus_corrected_H1_abs_null_sd':float(nullfh.std()),
                         'focus_corrected_H1_p':float((1+np.sum(nullfh>=fh))/(N+1))}
# Single sheet influence is not treated as preregistered inference.
small=[]
for ix in paths['path1']:
    r=test(paths['path1'][paths['path1']!=ix], 'd_net', n=4000,seed=20261124)
    small.append({'omitted':D.loc[ix,'sheet'],**{k:r[k] for k in ['obs','effect','null_sd','z']}})
res['leave_one_sheet_out']={'lowest':sorted(small,key=lambda s:s['z'])[:8], 'highest':sorted(small,key=lambda s:s['z'])[-3:]}
# Corpus-level structure checks
p=paths['path1']; b=paths['binding']
res['order_structure']={'path1_same_cluster_edges':int(np.sum(D.cluster.to_numpy()[p][1:]==D.cluster.to_numpy()[p][:-1])),
                        'path1_same_stratum_edges':int(np.sum(D.section_hand.to_numpy()[p][1:]==D.section_hand.to_numpy()[p][:-1])),
                        'binding_same_stratum_edges':int(np.sum(D.section_hand.to_numpy()[b][1:]==D.section_hand.to_numpy()[b][:-1])),
                        'n_edges':47,
                        'corr_dnet_focus':float(np.corrcoef(D.d_net,D.sigma)[0,1])}
res['source_checksum_limitations']='Independent sheet statistic approximately reproduces original phase2d_sheets but not bit-for-bit: mean abs difference 0.00056; our independent OLS uses 39 character counts and a length-redundant intercept rather than original full rank-deficient SVD.'

atomic_pickle({'data':D,'results':res,'orders':paths},'02_independent_bounding_results.pkl')
(OUT/'independent_bounds.json').write_text(json.dumps(res,indent=2,default=str))
D.to_csv(OUT/'independent_sheet_values_with_controls.csv',index=False)
print(json.dumps({k:res[k] for k in ['main','cluster_matched','focus','focus_cluster_matched','H1','H1_cluster_pair','order_structure','leave_one_sheet_out']},indent=2))
