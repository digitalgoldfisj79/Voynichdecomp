# Voynich conjugate-leaf darkness audit (2026-11-14)

Read `AUDIT_REPORT.md` first; retractions are at the top. `PREREG_RULES.txt` records the decision rule frozen before attacks. `RUNNING_RESULTS.md` maintains permanent retractions at the top. `RESULTS_TABLE.csv` provides the statistics in a machine-readable form.

Execution from independent page measurement table:

```bash
python rebuild_audit.py
python attacks.py
python plant_power.py
python scope_face.py
python tail_bound.py
python matched_power.py
python subset_power.py
```

Regenerate the page input from the original upstream word-level gzip using `python rebuild_word_page_input.py words_y2014.csv.gz regenerated.csv`; upstream source URLs are in the report. All results are based on real records. Inference and plant checks are simulation-based and explicitly labelled. Scripts checkpoint their outputs atomically under `results/`.
