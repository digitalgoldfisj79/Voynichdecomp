"""Known-answer planted-signal calibration. Predeclared normal and focus-correlated signals."""
from pathlib import Path
import numpy as np,pandas as pd,pickle,json,os
R=Path(__file__).parent/'results'
a=pickle.load(open(R/'01_baseline_word_rederivation.pkl','rb'))
b=pickle.load(open(R/'02_focus_skin_matched_nulls_influence.pkl','rb'))
p=a['pages'];L=a['leaves'];pidx=a['pairs'];null_idx=a['null_indexes']['random_repair'][:1300]
q=pd.get_dummies(L.quire,drop_first=True,dtype=float).to_numpy();FE=np.column_stack([np.ones(len(L)),q])
sigma=L.sigma.to_numpy();B=L.logB.to_numpy();D=L.D.to_numpy();sSheet=L.groupby('bifolium',sort=False).sigma.transform('mean').to_numpy()
Q={q:x.index.to_numpy() for q,x in L.groupby('quire')};pairSheet=np.repeat(np.arange(len(pidx)),2)

def detrend(y,model):
 return y-model@np.linalg.lstsq(model,y,rcond=None)[0]
Xleaf=np.column_stack([FE,sigma]);Xsheet=np.column_stack([FE,sSheet]);Xboth=np.column_stack([FE,sigma,sSheet,B,L.groupby('bifolium',sort=False).logB.transform('mean')])

def zstat(y):
 ob=np.abs(y[pidx[:,0]]-y[pidx[:,1]]).mean()
 nu=np.abs(y[null_idx[:,:,0]]-y[null_idx[:,:,1]]).mean(axis=1)
 sd=nu.std()
 return (nu.mean()-ob)/sd if sd else 0

rng=np.random.default_rng(20141114)
configs=[(0.03,0),(0.06,0),(0.09,0),(0.12,0),(0.06,0.8),(0.09,0.8),(0.12,0.8)]
N=600
powers=[]
for tau,r in configs:
 zraw=[];zl=[];zs=[];zboth=[]
 for i in range(N):
  base=D.copy()
  for q,inds in Q.items():base[inds]=rng.permutation(base[inds])
  correlated=(sSheet-sSheet.mean())/sSheet.std()
  novel=rng.normal(size=len(pidx));novel=np.repeat(novel,2)
  signal=tau*(r*correlated+np.sqrt(1-r*r)*novel)
  synthetic=base+signal
  zraw.append(zstat(synthetic));zl.append(zstat(detrend(synthetic,Xleaf)));zs.append(zstat(detrend(synthetic,Xsheet)));zboth.append(zstat(detrend(synthetic,Xboth)))
 powers.append({'plant_sheet_sd_log':tau,'latent_focus_correlation':r,'n_sim':N,'raw_power_z3':float(np.mean(np.array(zraw)>=3)),'leaf_focus_power_z3':float(np.mean(np.array(zl)>=3)),'sheet_focus_power_z3':float(np.mean(np.array(zs)>=3)),'all_focus_B_power_z3':float(np.mean(np.array(zboth)>=3)), 'raw_power_z2':float(np.mean(np.array(zraw)>=2)),'leaf_focus_power_z2':float(np.mean(np.array(zl)>=2)), 'sheet_focus_power_z2':float(np.mean(np.array(zs)>=2)), 'all_focus_B_power_z2':float(np.mean(np.array(zboth)>=2))})

# Plant direct facing-pair similarity, with real quire distributions and same random pair null.
p1=p[p.panel.isna()].copy().reset_index(drop=True);pa={x:i for i,x in enumerate(p1.page)};pval=p1.D.to_numpy();QS={q:sub.index.to_numpy() for q,sub in p1.groupby('quire')}
faces=[(pa[x],pa[y],q) for x,y,q,same in a['facing_pairs'] if not same]
assert len(faces)==45
ip=np.array([x[0] for x in faces],int);jp=np.array([x[1] for x in faces],int)
assert len(set(ip)&set(jp))==0 and len(np.unique(np.r_[ip,jp]))==90
qf=np.array([q for _,_,q in faces]);matchQ={q:np.where(qf==q)[0] for q in set(qf)}
rng=np.random.default_rng(2345);Ns=650
face_output=[]
for contraction in (0,0.25,0.5,0.75,1.0):
 zz=[];eff=[];ss=[]
 for rep in range(Ns):
  base=pval.copy()
  for q,inds in QS.items():base[inds]=rng.permutation(base[inds])
  before=base.copy()
  m=(base[ip]+base[jp])/2
  base[ip]=m+(1-contraction)*(before[ip]-m)
  base[jp]=m+(1-contraction)*(before[jp]-m)
  obs=float(np.abs(base[ip]-base[jp]).mean())
  # within-quire random page pairs, no self-pair, with replacement between pairs
  sim=np.zeros(450)
  for q,inds in QS.items():
   indsF=matchQ.get(q)
   if indsF is None: continue
   aa=rng.integers(0,len(inds),size=(450,len(indsF)))
   bb=rng.integers(0,len(inds)-1,size=(450,len(indsF)))
   bb+=(bb>=aa)
   sim+=np.abs(base[inds[aa]]-base[inds[bb]]).sum(axis=1)
  sim/=len(faces); mu=sim.mean();sd=sim.std();z=(mu-obs)/sd
  zz.append(z);eff.append(mu-obs);ss.append(sd)
 face_output.append({'contraction':contraction,'n_sim':Ns,'power_z3':float(np.mean(np.array(zz)>=3)),'power_z2':float(np.mean(np.array(zz)>=2)),'median_effect':float(np.median(eff)),'median_null_sd':float(np.median(ss)),'median_z':float(np.median(zz)),'mean_unmodified_gap':float(np.mean([np.abs(pval[ip]-pval[jp]).mean()])),'calibration':'Quire-shuffled null pages, paired contraction, random same-quire page pairs'})

results={'sheet_plants':powers,'facing_plants':face_output}
T=R/'03_planted_power.pkl';tmp=T.with_suffix('.tmp')
with tmp.open('wb') as f:pickle.dump(results,f);f.flush();os.fsync(f.fileno())
os.replace(tmp,T)
(R/'03_planted_power.json').write_text(json.dumps(results,indent=2))
with open(Path(__file__).parent/'RUNNING_RESULTS.md','a') as f:f.write('\n## Planted-signal power, independent simulation\n'+json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
