"""Prespecified attacks after independent word->page->leaf reconstruction.
No use of analysis6.py or phase9.py. Every checkpoint saved atomically.
"""
from pathlib import Path
import numpy as np, pandas as pd, pickle, json, os, itertools, math
from scipy.optimize import linear_sum_assignment
from collections import Counter,defaultdict
ROOT=Path(__file__).parent
R=ROOT/'results'

b=pickle.load(open(R/'01_baseline_word_rederivation.pkl','rb'))
p=b['pages'];L=b['leaves'];pairs=b['pairs'];nulls=b['null_indexes'];facing=b['facing_pairs']

def persist(name,data):
 f=R/(name+'.pkl');t=f.with_suffix('.tmp')
 with open(t,'wb') as g:pickle.dump(data,g,pickle.HIGHEST_PROTOCOL);g.flush();os.fsync(g.fileno())
 os.replace(t,f)
 return str(f)

def result(v,mat=nulls['random_repair'], idx=pairs):
 v=np.asarray(v,float)
 obs=float(np.abs(v[idx[:,0]]-v[idx[:,1]]).mean())
 nv=np.abs(v[mat[:,:,0]]-v[mat[:,:,1]]).mean(axis=1)
 mu=float(nv.mean());sd=float(nv.std())
 return dict(n=len(idx),obs=obs,null_mean=mu,null_sd=sd,effect=mu-obs,z=(mu-obs)/sd,p=(1+int((nv<=obs).sum()))/(len(nv)+1))

# Pre-registered adjustment: within-quire fixed effects and leaf-focus, leaf-B, and additive sheet-focus.
# Note that subtraction of a SHEET-COMMON prediction cannot change within-true-sheet gaps: test null contrast also.
q=pd.get_dummies(L.quire,drop_first=True,dtype=float)
FE=np.column_stack([np.ones(len(L)),q.to_numpy()])
by=L.groupby('bifolium',sort=False)
sheet_sigma=by.sigma.transform('mean').values
sheet_bg=by.logB.transform('mean').values

def resid(y,*xs):
 X=np.column_stack([FE,*xs]);return np.asarray(y)-X@np.linalg.lstsq(X,y,rcond=None)[0]
D=L.D.to_numpy();sigma=L.sigma.to_numpy();B=L.logB.to_numpy()
variants={
 'raw':D,
 'leaf_focus':resid(D,sigma),
 'sheet_focus':resid(D,sheet_sigma),
 'leaf_B':resid(D,B),
 'sheet_B':resid(D,sheet_bg),
 'leaf_focus_B':resid(D,sigma,B),
 'leaf_plus_sheet_focus':resid(D,sigma,sheet_sigma),
 'leaf_plus_sheet_B':resid(D,B,sheet_bg),
 'full_focus_B_multilevel':resid(D,sigma,sheet_sigma,B,sheet_bg),
 'within_quire_only':resid(D),
}
results={k:result(v) for k,v in variants.items()}
results['focus_only_shared']=result(sigma)
results['background_only_shared']=result(B)
results['focus_background_correlations']={
 'all_leaves_D_sigma':float(np.corrcoef(D,sigma)[0,1]),
 'within_quire_D_sigma':float(np.corrcoef(resid(D),resid(sigma))[0,1]),
 'within_quire_D_logB':float(np.corrcoef(resid(D),resid(B))[0,1]),
 'leaf_sigma_logB':float(np.corrcoef(sigma,B)[0,1]),
 'between_sheets_D_sigma':float(by.D.mean().corr(by.sigma.mean())),
 'between_sheets_D_logB':float(by.D.mean().corr(by.logB.mean())),
 'conjugate_delta_D_vs_delta_sigma':float(np.corrcoef((D[pairs[:,0]]-D[pairs[:,1]]),(sigma[pairs[:,0]]-sigma[pairs[:,1]]))[0,1]),
}

# Stricter 1, opposite quire wings. Stricter 2, opposite wings conditioned on focus+parchment
# with a predeclared unit-temperature Gaussian weighting; exploratory sensitivity, not exchangeability-proof.
C=nulls['crosswing'];results['crosswing']=result(D,C)
focus_scale=float(np.std(resid(sigma)));B_scale=float(np.std(resid(B)))
conditioned_indices=[]
for q,sub in L.groupby('quire',sort=False):
 left=sub[sub.wing==0].index.to_numpy();right=sub[sub.wing==1].index.to_numpy();n=len(left)
 options=[];weights=[]
 for pp in itertools.permutations(right):
  pp=np.asarray(pp)
  d_focus=(sigma[left]-sigma[pp])/focus_scale
  d_bg=(B[left]-B[pp])/B_scale
  cost=float(np.sum(d_focus**2+d_bg**2))
  options.append(np.column_stack([left,pp]));weights.append(-0.5*cost)
 w=np.exp(weights-np.max(weights));w/=w.sum()
 conditioned_indices.append((q,np.array(options),w))
NR=30000;random=np.random.default_rng(20261114)
matchnull=np.empty((NR,len(pairs),2),dtype=np.int16);st=0
for q,options,weights in conditioned_indices:
 pick=random.choice(len(options),size=NR,p=weights)
 matchnull[:,st:st+options.shape[1],:]=options[pick]
 st+=options.shape[1]
results['focus_B_matched_crosswing']=result(D,matchnull)
results['focus_B_matched_crosswing_residual']=result(variants['leaf_focus_B'],matchnull)
results['matched_null_parameters']={'focus_scale':focus_scale,'B_scale':B_scale,'temperature':1.0,'conditioning_is_sensitivity_not_permutation_p':True}

# Material-only synthetic: what fraction of observed gap reduction can observed B account for at most?
# Estimate within-quire model. This is an association audit, not causal identification.
coefs={}
for name,XX in [('B',B),('sigma',sigma),('B_sigma',np.column_stack([B,sigma]))]:
 x=np.column_stack([FE,XX]);fit=x@np.linalg.lstsq(x,D,rcond=None)[0]
 coefs[name]={'observed_model_R2':float(1-np.sum((D-fit)**2)/np.sum((D-D.mean())**2)),
              'fitted_component_shared':result(fit), 'residual_shared':result(D-fit)}
results['fitted_background_components']=coefs

# Single panel only: require both leaves measured and all measured page records have panel missing, and quire>=2
keep_sheets=[s for s,g in L.groupby('bifolium') if not g.has_panel.any()]
strict=L[L.bifolium.isin(keep_sheets)].copy()
strict=strict[strict.quire.isin(strict.groupby('quire').bifolium.nunique().loc[lambda v:v>=2].index)].copy().reset_index(drop=True)
strictpair=np.arange(len(strict)).reshape(-1,2)
assert len(strict)==66 and len(strictpair)==33,(len(strict),len(strictpair))
RNG=np.random.default_rng(1440)
N=20000
nx=np.empty((N,len(strictpair),2),np.int16)
start=0
for q,g in strict.groupby('quire'):
 ii=g.index.to_numpy();count=len(ii)//2
 nx[:,start:start+count,:]=np.stack([RNG.permutation(ii) for _ in range(N)]).reshape(N,count,2)
 start+=count
results['strict_single_panel']=result(strict.D,nx,strictpair)

# Adversarial but explicitly NON-NULL: optimal (outcome-aware) cross-wing pairing by darkness, within quire.
optimal=[]
for q,g in L.groupby('quire'):
 left=g[g.wing==0].index.to_numpy();right=g[g.wing==1].index.to_numpy()
 cc=np.abs(D[left,None]-D[None,right]);ix,iy=linear_sum_assignment(cc)
 optimal.extend((int(left[a]),int(right[c])) for a,c in zip(ix,iy))
results['oracle_outcome_matching_NOT_VALID_NULL']={
 'mean_absolute_gap':float(np.abs(D[np.array(optimal)[:,0]]-D[np.array(optimal)[:,1]]).mean()),
 'observed':float(np.abs(D[pairs[:,0]]-D[pairs[:,1]]).mean())}

# Influence: heldout one sheet and greedy deletion; recompute valid quire strata and null each time.
def excluded_sheets_out(exclude,N=4000,seed=1717):
 sub=L[~L.bifolium.isin(exclude)].copy().reset_index(drop=True)
 sub=sub[sub.quire.isin(sub.groupby('quire').bifolium.nunique().loc[lambda v:v>=2].index)].reset_index(drop=True)
 inds=np.arange(len(sub)).reshape(-1,2)
 rnd=np.random.default_rng(seed);n=len(inds);pm=np.empty((N,n,2),np.int16);at=0
 for q,group in sub.groupby('quire'):
  loc=group.index.to_numpy();count=len(loc)//2
  pm[:,at:at+count,:]=np.stack([rnd.permutation(loc) for i in range(N)]).reshape(N,count,2)
  at+=count
 return result(sub.D,pm,inds),sub

jack=[]
for sh in L.bifolium.unique():
 rr,_=excluded_sheets_out([sh],N=1200)
 jack.append({'sheet':sh,**rr})
jack.sort(key=lambda x:x['z'])
results['leave_one_sheet_out']={'least_z':jack[:8], 'greatest_z':jack[-3:], 'minimum_z':min(r['z'] for r in jack)}

# Adversarial greedy influential-shard removal, every choice optimized *after* seeing the outcome; sensitivity not valid p.
exclude=[];history=[];pool=set(L.bifolium.unique())
for iteration in range(7):
 cands=[]
 for sh in pool:
  rr,sub=excluded_sheets_out(exclude+[sh],N=350,seed=777)
  if rr['n']<12:continue
  cands.append((rr['z'],sh,rr))
 if not cands:break
 zmin,chosen,rr=min(cands,key=lambda x:x[0]);exclude.append(chosen);pool.remove(chosen)
 history.append({'removed':exclude.copy(),**rr})
 if zmin<2:break
results['greedy_minimum_removals_to_below_2SD']={'history':history,'threshold_reached':any(x['z']<2 for x in history),'selection_post_hoc':True}

# Multiple testing: permutation lower bound and correction count. Larger sampling to resolve the tail.
N=20000; RNG=np.random.default_rng(811)
obs=float(np.abs(D[pairs[:,0]]-D[pairs[:,1]]).mean());hits=0;mean0=0;M2=0
for trial in range(N):
 dif=[]
 for q,group in L.groupby('quire'):
  vals=D[RNG.permutation(group.index.values)].reshape(-1,2)
  dif.extend(np.abs(vals[:,0]-vals[:,1]))
 x=float(np.mean(dif));hits+=x<=obs
 delta=x-mean0;mean0+=delta/(trial+1);M2+=delta*(x-mean0)
raw_p=(hits+1)/(N+1)
results['familywise_340']={'permutations':N,'hits':hits,'empirical_p':raw_p,'bonferroni_340_upper':min(1.0,340*raw_p),'null_mean':mean0,'null_sd':math.sqrt(M2/N),'effect':mean0-obs,'z':(mean0-obs)/math.sqrt(M2/N),'selection_family_340_approx_not_independent':True}

persist('02_focus_skin_matched_nulls_influence',{'results':results,'variants':variants,'matched_indexes':matchnull,'strict_leaves':strict,'jack':jack})
(R/'02_attack_results.json').write_text(json.dumps(results,indent=2,default=float))
with open(ROOT/'RUNNING_RESULTS.md','a') as f:f.write('\n## Attack 2: focus, skin, nulls, influence, multiplicity\n'+json.dumps(results,indent=2,default=float)+'\n')
print(json.dumps(results,indent=2,default=float))
