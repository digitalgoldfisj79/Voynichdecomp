from pathlib import Path
import pickle, numpy as np, os, json
R=Path(__file__).parent/'results';d=pickle.load(open(R/'01_baseline_word_rederivation.pkl','rb'))
leaf=d['leaves'];pairs=d['pairs'];D=leaf.D.to_numpy();obs=float(np.mean(abs(D[pairs[:,0]]-D[pairs[:,1]])))
blocks=[g.index.to_numpy() for _,g in leaf.groupby('quire')]
N=500000;batch=10000;rng=np.random.default_rng(1042026)
hits=0;ss=0;ss2=0;total=0
for step in range(0,N,batch):
 M=min(batch,N-step);scores=np.zeros(M)
 for ix in blocks:
  arr=np.broadcast_to(D[ix],(M,len(ix)))
  shuffled=rng.permuted(arr,axis=1).reshape(M,-1,2)
  scores+=np.abs(shuffled[:,:,0]-shuffled[:,:,1]).sum(axis=1)
 scores/=len(pairs)
 hits+=int((scores<=obs).sum());ss+=float(scores.sum());ss2+=float(np.dot(scores,scores));total+=M
mean=ss/total;sd=(ss2/total-mean*mean)**0.5
result={'N':N,'hits':hits,'empirical_p_plus1':(hits+1)/(N+1),'bonferroni_340_upper':340*(hits+1)/(N+1),'bonferroni_417_upper':417*(hits+1)/(N+1),'observed':obs,'null_mean':mean,'null_sd':sd,'effect':mean-obs,'z':(mean-obs)/sd,'note':'Monte Carlo upper bound when hits=0 is the +1 estimator, not a confidence interval'}
path=R/'05_extended_tail.pkl';tmp=path.with_suffix('.tmp')
with tmp.open('wb') as f:pickle.dump(result,f);f.flush();os.fsync(f.fileno())
os.replace(tmp,path)
(R/'05_extended_tail.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
