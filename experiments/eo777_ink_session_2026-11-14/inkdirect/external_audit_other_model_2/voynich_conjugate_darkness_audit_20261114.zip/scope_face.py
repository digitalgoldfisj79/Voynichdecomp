"""Independent quire-scope and skin-face geometry tests; not read from original code."""
from pathlib import Path
import numpy as np, pandas as pd,pickle,json,os
P=Path(__file__).parent;R=P/'results'
a=pickle.load(open(R/'01_baseline_word_rederivation.pkl','rb')); L=a['leaves'];p=a['pages']

def test_sub(sub, n=30000, seed=1203):
 sub=sub.reset_index(drop=True)
 assert sub.groupby('bifolium').size().eq(2).all()
 groups=list(sub.groupby('quire'))
 groups=[(k,g) for k,g in groups if len(g)>=4]
 sub=pd.concat([g for q,g in groups]).reset_index(drop=True)
 idx=np.arange(len(sub)).reshape(-1,2);D=sub.D.to_numpy();ob=np.abs(D[idx[:,0]]-D[idx[:,1]]).mean()
 random=np.random.default_rng(seed);null=np.zeros(n);qidx=[g.index.to_numpy() for _,g in sub.groupby('quire')]
 for j in range(n):
  dif=[]
  for inds in qidx:
   z=D[random.permutation(inds)].reshape(-1,2);dif.extend(np.abs(z[:,0]-z[:,1]))
  null[j]=np.mean(dif)
 mu=null.mean();sd=null.std();return {'n_sheets':len(idx),'observed':ob,'null_mean':mu,'null_sd':sd,'effect':mu-ob,'z':(mu-ob)/sd,'p':(1+int((null<=ob).sum()))/(n+1),'qui':list(k for k,g in sub.groupby('quire'))}

runs={}
for name,quires in [('herbal',set('ABCDEFG')),('balneo_stars',{'M','T'}),('later',{'O','Q'}),('ex_herbal',{'M','T','O','Q'})]:
 runs[name]=test_sub(L[L.quire.isin(quires)])
for q in L.quire.unique():
 runs['exclude_'+q]=test_sub(L[L.quire!=q],n=5000)

# Complete 4-page bifolia. Leaf is lower or higher wing in quire.
# Within a bifolium, outer/inner R vs V on physical sides depend on fold orientation.
complete=[]
for sh,g in p[p.panel.isna()].groupby('bifolium'):
 if len(g)!=4 or g.leaf.nunique()!=2:continue
 gg={ (r.leaf,r.side):r for _,r in g.iterrows()}
 if len(gg)!=4:continue
 lo,hi=sorted(g.leaf.unique())
 # Equally plausible physical side assignments, compare (a_r,b_v) and (a_v,b_r)
 # versus cross-sheet-face (a_r,b_r) and (a_v,b_v)
 for field in ['D','sigma','logB']:
  row={'sh':sh,'field':field,'q':g.quire.iloc[0]}
  get=lambda l,side:float(gg[(l,side)][field])
  row['same_face']=np.mean([abs(get(lo,'r')-get(hi,'v')),abs(get(lo,'v')-get(hi,'r'))])
  row['opposite_face']=np.mean([abs(get(lo,'r')-get(hi,'r')),abs(get(lo,'v')-get(hi,'v'))])
  row['same_leaf']=np.mean([abs(get(lo,'r')-get(lo,'v')),abs(get(hi,'r')-get(hi,'v'))])
  complete.append(row)
com=pd.DataFrame(complete)
RNG=np.random.default_rng(612)
face_results={}
for metric,gg in com.groupby('field'):
 for pair in [('same_face','opposite_face'),('same_face','same_leaf')]:
  d=(gg[pair[1]]-gg[pair[0]]).to_numpy();obs=d.mean()
  # Null swapping the physical-face assignment within each complete bifolium
  signs=RNG.choice([-1,1],size=(50000,len(d)))
  null=(signs*d).mean(axis=1)
  mu=null.mean();sd=null.std()
  face_results[f'{metric}_{pair[0]}_vs_{pair[1]}']={
   'n_complete_sheets':len(d),'same_face_gap':float(gg.same_face.mean()),'comparator_gap':float(gg[pair[1]].mean()),'effect':obs-mu,'null_mean':mu,'null_sd':sd,'z':(obs-mu)/sd,'p_two_sided':(1+np.sum(abs(null)>=abs(obs)))/(len(null)+1),
   'note':'paired sign-flip of which physical-side comparison is smaller'}

out={'scope':runs,'same_sheet_face_geometry':face_results,'complete_sheets':com.sh.nunique()}
tmp=R/'04_scope_face.tmp';f=R/'04_scope_face.pkl'
with tmp.open('wb') as x:pickle.dump({'output':out,'face_rows':com},x);x.flush();os.fsync(x.fileno())
os.replace(tmp,f)
(R/'04_scope_face.json').write_text(json.dumps(out,indent=2,default=float))
with open(P/'RUNNING_RESULTS.md','a') as x:x.write('\n## Quire scope and same-sheet-face geometry (independent)\n'+json.dumps(out,indent=2,default=float)+'\n')
print(json.dumps(out,indent=2,default=float))
