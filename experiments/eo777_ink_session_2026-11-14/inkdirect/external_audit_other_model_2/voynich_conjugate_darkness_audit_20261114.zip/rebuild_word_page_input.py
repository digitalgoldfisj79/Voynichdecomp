"""Clean-room Python alternative to independently reproduce word->page measurements.
Inputs: repo/inkdirect/words_y2014.csv.gz and eo777/vms-spatial physical_map.csv.
The included independent_word_page_stats.csv was produced from the same gzip source
by a separate, independently authored JavaScript inflate+OLS implementation.
This script does not import analysis6.py, phase9.py, or the session log.
Usage: python rebuild_word_page_input.py words_y2014.csv.gz output.csv
"""
from pathlib import Path
import sys,re
import numpy as np,pandas as pd
if len(sys.argv)!=3:raise SystemExit(__doc__)
w=pd.read_csv(sys.argv[1],keep_default_na=False)
for c in ['darkness','peak','sigma_hat','width_px','B']:
 w[c]=pd.to_numeric(w[c],errors='coerce')
w=w[(w.darkness>0)&(w.peak>0)&w.sigma_hat.notna()&(w.width_px>0)].copy()
assert len(w)==11309,len(w)
chars=sorted(set(''.join(w.word.astype(str))))
X=np.ones((len(w),1+len(chars)),dtype=float)
for j,c in enumerate(chars,1):X[:,j]=w.word.str.count(re.escape(c))
y=np.log(w.darkness.values)
w['D']=y-X@np.linalg.lstsq(X,y,rcond=None)[0]
counts=w.groupby('page').size();w=w[w.page.isin(counts.index[counts>=20])].copy()
mean=lambda a: a.mean()
P=w.groupby('page').agg(n=('D','size'),D=('D','mean'),Draw=('darkness','mean'),B=('B','mean'),sigma=('sigma_hat','mean'))
w['logB']=np.log(w.B)
P['logB']=w.groupby('page').logB.mean()
fore=w[w.fore.astype(str).str.lower().eq('true')]
P['fore_n']=fore.groupby('page').size()
P['Dfore']=fore.groupby('page').D.mean()
P['sig_fore']=fore.groupby('page').sigma_hat.mean()
P[['n','fore_n','D','Dfore','Draw','B','logB','sigma','sig_fore']].reset_index().to_csv(sys.argv[2],index=False)
assert len(P)==151
print('saved',sys.argv[2],len(P),'pages',len(w),'words')
