from pathlib import Path
import pickle,numpy as np,json,os
R=Path(__file__).parent/'results';a=pickle.load(open(R/'01_baseline_word_rederivation.pkl','rb'));L=a['leaves'];rng=np.random.default_rng(231114)
result=[]
for group,quires in [('herbal',set('ABCDEFG')),('M_T',{'M','T'})]:
 sub=L[L.quire.isin(quires)].reset_index(drop=True);D=sub.D.to_numpy();n=len(sub)//2;ip=np.arange(len(sub)).reshape(-1,2)
 qlist=[g.index.to_numpy() for _,g in sub.groupby('quire')]
 nullidx=np.empty((1300,n,2),np.int16);at=0
 for inds in qlist:
  m=len(inds)//2;nullidx[:,at:at+m,:]=np.stack([rng.permutation(inds) for _ in range(1300)]).reshape(-1,m,2);at+=m
 for tau in [0.08,0.12,0.16]:
  z=[]
  for rep in range(600):
   base=D.copy()
   for inds in qlist:base[inds]=rng.permutation(base[inds])
   base+=np.repeat(rng.normal(0,tau,n),2)
   obs=abs(base[ip[:,0]]-base[ip[:,1]]).mean()
   v=abs(base[nullidx[:,:,0]]-base[nullidx[:,:,1]]).mean(axis=1)
   z.append((v.mean()-obs)/v.std())
  z=np.asarray(z)
  result.append({'group':group,'n_sheets':n,'tau':tau,'plants':600,'power_z3':float((z>=3).mean()),'power_z2':float((z>=2).mean())})
path=R/'07_subset_power.pkl';t=path.with_suffix('.tmp')
with open(t,'wb') as f:pickle.dump(result,f);f.flush();os.fsync(f.fileno())
os.replace(t,path)
(R/'07_subset_power.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
