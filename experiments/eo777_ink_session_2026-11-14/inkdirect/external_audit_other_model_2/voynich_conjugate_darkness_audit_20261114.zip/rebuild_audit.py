"""Independent audit from *original word-derived page means*.
Input rows computed independently in JS from the source gzip, glyph OLS, then page means.
Metadata mapping is reconstructed from eo777 physical_map (quire ranges and pairing).
No imports of original analysis6 or phase9.
"""
from pathlib import Path
from collections import defaultdict
import os, pickle, json, re, math, itertools
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

ROOT=Path(__file__).parent
OUT=ROOT/'results'
OUT.mkdir(exist_ok=True)
RUN_FILE=ROOT/'RUNNING_RESULTS.md'
RETRACTIONS=['The negative-control claim that all 49 facing pairs are DIFFERENT sheets is false: four are same-sheet central folds.',
             'The 37-sheet primary is NOT exclusively single-panel: it includes sheets with panel identifiers. A strict single-panel analysis has 33 pairs.',
             'A non-significant facing-pages test is not evidence of absence unless planted power is adequate.']
if not RUN_FILE.exists():
 RUN_FILE.write_text('# RETRACTED / DOWNGRADED FINDINGS (TOP)\n'+''.join(f'- {r}\n' for r in RETRACTIONS)+'\n# RUNNING RESULTS\n')

def persist(name,data):
 path=OUT/(name+'.pkl');temp=path.with_suffix('.tmp')
 with temp.open('wb') as f: pickle.dump(data,f,pickle.HIGHEST_PROTOCOL);f.flush();os.fsync(f.fileno())
 os.replace(temp,path)
 return path

def log(obj):
 with RUN_FILE.open('a') as f:f.write(json.dumps(obj,indent=2,default=lambda x:float(x) if isinstance(x,np.generic) else str(x))+'\n\n')

# Independent physical-map cross-check: all measured pages must belong to known quire ranges.
QUIRES=[('A',1,8),('B',9,16),('C',17,24),('D',25,32),('E',33,40),('F',41,48),('G',49,56),('H',57,66),('M',75,84),('N',85,86),('O',87,90),('Q',93,96),('S',99,102),('T',103,116)]

def annotate(page):
 m=re.fullmatch(r'f(\d+)([rv])(\d*)',page)
 if not m: raise ValueError(f'Unrecognised page {page}')
 leaf=int(m[1]); side=m[2];panel=m[3]
 for q,start,end in QUIRES:
  if start<=leaf<=end:
   # Quire H surviving text only at 57,58,65,66; symmetrical mapping holds.
   partner=start+end-leaf
   return {'leaf':leaf,'side':side,'panel':panel,'quire':q,'partner_leaf':partner,'bifolium':f'{q}:{min(leaf,partner)}-{max(leaf,partner)}','wing':0 if leaf<partner else 1}
 raise ValueError('Leaf absent from mapped quires '+page)

p=pd.read_csv(ROOT/'independent_word_page_stats.csv')
assert len(p)==151 and p.page.nunique()==151
for key in ['leaf','side','panel','quire','partner_leaf','bifolium','wing']:
 p[key]=[annotate(v)[key] for v in p.page]
p['panel']=p['panel'].replace('',np.nan)

# A source entry for each PAGE/PANEL. LF arithmetic mean across available pages of a single physical leaf.
leaf=p.groupby(['bifolium','leaf','quire','wing'],as_index=False).agg(D=('D','mean'),Dfore=('Dfore','mean'),Draw=('Draw','mean'),B=('B','mean'),logB=('logB','mean'),sigma=('sigma','mean'),sig_fore=('sig_fore','mean'),nwords=('n','sum'),npages=('page','size'),has_panel=('panel',lambda s:s.notna().any()))
pair_counts=leaf.groupby('bifolium').size()
leaf=leaf[leaf.bifolium.isin(pair_counts[pair_counts==2].index)].copy()
qcounts=leaf.groupby('quire').bifolium.nunique()
leaf=leaf[leaf.quire.isin(qcounts[qcounts>=2].index)].sort_values(['quire','bifolium','wing']).reset_index(drop=True)
assert len(leaf)==74, len(leaf)
assert leaf.groupby('bifolium').size().eq(2).all()
assert (leaf.groupby('bifolium').wing.sum()==1).all()
assert leaf.bifolium.nunique()==37

# Original nested within-quire null: permute the 2n leaf measurements, re-pair contiguous slots.
# No computational dependence on analysis6 or prior scripts.
rng=np.random.default_rng(20261124)
Q={q:np.array(x.index) for q,x in leaf.groupby('quire')}
idx=np.arange(len(leaf)).reshape(-1,2)
assert np.all(leaf.loc[idx[:,0],'bifolium'].values==leaf.loc[idx[:,1],'bifolium'].values)
all_quire_groups=[]
for q,inds in Q.items():
 assert len(inds)%2==0
 all_quire_groups.append((q,inds))

# Cache permutation index arrays (rows=permutations; columns=pairs, pair axes=2)
def pair_index_null(method,N,seed=20261124):
 R=np.random.default_rng(seed)
 null=np.empty((N,len(idx),2),np.int16)
 keys={int(x):int(j) for j,x in enumerate(leaf.index)}
 start=0
 for q,inds in all_quire_groups:
  n=len(inds)//2
  if method=='random_repair':
   a=np.stack([R.permutation(inds) for i in range(N)]).reshape(N,n,2)
  elif method=='crosswing':
   left=leaf.loc[inds][lambda d:d.wing==0].index.to_numpy()
   right=leaf.loc[inds][lambda d:d.wing==1].index.to_numpy()
   a=np.stack([np.column_stack([left,R.permutation(right)]) for i in range(N)])
  else:raise ValueError(method)
  null[:,start:start+n,:]=a
  start+=n
 return null

NULLS={m:pair_index_null(m,15000,10081) for m in ['random_repair','crosswing']}

def ev(v,method='random_repair',nulls=None):
 v=np.asarray(v,float)
 obs=np.abs(v[idx[:,0]]-v[idx[:,1]]).mean()
 mat=NULLS[method] if nulls is None else nulls
 sims=np.abs(v[mat[:,:,0]]-v[mat[:,:,1]]).mean(axis=1)
 mu=float(sims.mean());sd=float(sims.std());effect=mu-float(obs)
 return dict(n_sheets=len(idx),observed=float(obs),null_mean=mu,null_sd=sd,effect=effect,z=effect/sd if sd>0 else None,p=(1+int((sims<=obs).sum()))/(len(sims)+1))

baseline={}
for key in ['D','Dfore','Draw','sigma','logB','B']:
 baseline[key]=ev(leaf[key])
for method in NULLS:baseline['D_'+method]=ev(leaf.D,method)

# Facing study from actual page side+leaf data, excluding panel pages and with a strict different-sheet control.
p1=p[p.panel.isna()].copy().set_index(['leaf','side'])
facing=[]
for _,r in p[p.panel.isna()&(p.side=='v')].iterrows():
 if (r.leaf+1,'r') not in p1.index:continue
 s=p1.loc[(r.leaf+1,'r')]
 if s.quire!=r.quire:continue
 facing.append((r.page,s.page,r.quire,r.bifolium==s.bifolium))
assert len(facing)==49, len(facing)
assert sum(t[3] for t in facing)==4
pmap=p.set_index('page')
page0=p[p.panel.isna()].copy()
Qpages={q:rows.page.tolist() for q,rows in page0.groupby('quire')}

def face_stats(faces,arr=None,N=15000,seed=123):
 R=np.random.default_rng(seed)
 ds=pmap.D.to_dict() if arr is None else arr
 obs=np.mean([abs(ds[a]-ds[b]) for a,b,q,same in faces]);sim=np.empty(N)
 byq=defaultdict(list)
 for k,(a,b,q,same) in enumerate(faces):byq[q].append(k)
 for j in range(N):
  vals=[]
  for q,pids in byq.items():
   choices=Qpages[q];aidx=R.integers(0,len(choices),size=len(pids));bidx=R.integers(0,len(choices)-1,size=len(pids));bidx+=(bidx>=aidx)
   vals.extend(abs(ds[choices[a]]-ds[choices[b]]) for a,b in zip(aidx,bidx))
  sim[j]=np.mean(vals)
 mu=sim.mean();sd=sim.std()
 return dict(n_pairs=len(faces),observed=obs,null_mean=mu,null_sd=sd,effect=mu-obs,z=(mu-obs)/sd,p=(1+int(np.sum(sim<=obs)))/(N+1))

faces={'all':face_stats(facing),'strict_different_sheet':face_stats([x for x in facing if not x[3]])}

phase1={'source':{'word_rows':11309,'pages':len(p),'wordfile_sha':'e009ac3bde66505a18eb8332232e23f8ff5f9b04'},
        'baseline':baseline,'facing':faces,'includes_panels':[x for x,g in leaf.groupby('bifolium') if g.has_panel.any()]}

persist('01_baseline_word_rederivation',{'pages':p,'leaves':leaf,'pairs':idx,'null_indexes':NULLS,'baseline':phase1,'facing_pairs':facing})
(RUN_FILE.parent/'01_baseline_summary.json').write_text(json.dumps(phase1,indent=2,default=float))
log({'phase':'01 independently reconstructed base, before adjusting controls','results':phase1})
print(json.dumps(phase1,indent=2,default=float))
