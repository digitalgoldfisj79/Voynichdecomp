# RETRACTED / DOWNGRADED FINDINGS (TOP)
- The negative-control claim that all 49 facing pairs are DIFFERENT sheets is false: four are same-sheet central folds.
- The 37-sheet primary is NOT exclusively single-panel: it includes sheets with panel identifiers. A strict single-panel analysis has 33 pairs.
- A non-significant facing-pages test is not evidence of absence unless planted power is adequate.

- RETRACTED as a generality: a same-sheet darkness effect detected across 37 sheets cannot be described as established THROUGHOUT the manuscript. The M/T subgroup (11 sheets) is inconclusive (effect 0.00457, null SD 0.01244). Adequate non-herbal power is missing.

# RUNNING RESULTS
{
  "phase": "01 independently reconstructed base, before adjusting controls",
  "results": {
    "source": {
      "word_rows": 11309,
      "pages": 151,
      "wordfile_sha": "e009ac3bde66505a18eb8332232e23f8ff5f9b04"
    },
    "baseline": {
      "D": {
        "n_sheets": 37,
        "observed": 0.056743477027027034,
        "null_mean": 0.11033829072162162,
        "null_sd": 0.010420571232452772,
        "effect": 0.05359481369459458,
        "z": 5.143174255906847,
        "p": 6.666222251849876e-05
      },
      "Dfore": {
        "n_sheets": 37,
        "observed": 0.0665089527027027,
        "null_mean": 0.11699871558234234,
        "null_sd": 0.01115787553658055,
        "effect": 0.050489762879639646,
        "z": 4.525033705037435,
        "p": 6.666222251849876e-05
      },
      "Draw": {
        "n_sheets": 37,
        "observed": 0.022834055405405406,
        "null_mean": 0.04223814661423422,
        "null_sd": 0.003972997318758259,
        "effect": 0.019404091208828817,
        "z": 4.88399302894407,
        "p": 6.666222251849876e-05
      },
      "sigma": {
        "n_sheets": 37,
        "observed": 0.08897683783783789,
        "null_mean": 0.12315095062018021,
        "null_sd": 0.010721496062657949,
        "effect": 0.03417411278234232,
        "z": 3.1874388222151038,
        "p": 0.0023998400106659554
      },
      "logB": {
        "n_sheets": 37,
        "observed": 0.018224074324324466,
        "null_mean": 0.026057157712432482,
        "null_sd": 0.0021215231693398583,
        "effect": 0.007833083388108016,
        "z": 3.6921978988074824,
        "p": 0.00033331111259249385
      },
      "B": {
        "n_sheets": 37,
        "observed": 3.465689037837835,
        "null_mean": 5.0100523714153145,
        "null_sd": 0.4082199853594751,
        "effect": 1.5443633335774796,
        "z": 3.7831644431066405,
        "p": 0.00026664889007399506
      },
      "D_random_repair": {
        "n_sheets": 37,
        "observed": 0.056743477027027034,
        "null_mean": 0.11033829072162162,
        "null_sd": 0.010420571232452772,
        "effect": 0.05359481369459458,
        "z": 5.143174255906847,
        "p": 6.666222251849876e-05
      },
      "D_crosswing": {
        "n_sheets": 37,
        "observed": 0.056743477027027034,
        "null_mean": 0.10332568350972973,
        "null_sd": 0.011549626715981545,
        "effect": 0.0465822064827027,
        "z": 4.033221819909174,
        "p": 0.00013332444503699753
      }
    },
    "facing": {
      "all": {
        "n_pairs": 49,
        "observed": 0.12956011632653064,
        "null_mean": 0.1225371415597279,
        "null_sd": 0.012563405779731664,
        "effect": -0.007022974766802734,
        "z": -0.5590024623842671,
        "p": 0.7158189454036398
      },
      "strict_different_sheet": {
        "n_pairs": 45,
        "observed": 0.13377966222222223,
        "null_mean": 0.12252721999096296,
        "null_sd": 0.013018906939905952,
        "effect": -0.011252442231259277,
        "z": -0.8643154362497167,
        "p": 0.8054129724685021
      }
    },
    "includes_panels": [
      "O:87-90",
      "O:88-89",
      "Q:94-95"
    ]
  }
}


## Attack 2: focus, skin, nulls, influence, multiplicity
{
  "raw": {
    "n": 37,
    "obs": 0.056743477027027034,
    "null_mean": 0.11033829072162162,
    "null_sd": 0.010420571232452772,
    "effect": 0.05359481369459458,
    "z": 5.143174255906847,
    "p": 6.666222251849876e-05
  },
  "leaf_focus": {
    "n": 37,
    "obs": 0.06977460967623834,
    "null_mean": 0.09381859858299814,
    "null_sd": 0.007465773084311858,
    "effect": 0.024043988906759794,
    "z": 3.2205625104363858,
    "p": 0.0007999466702219852
  },
  "sheet_focus": {
    "n": 37,
    "obs": 0.056743477027027034,
    "null_mean": 0.08342879558110929,
    "null_sd": 0.007934348546590775,
    "effect": 0.026685318554082252,
    "z": 3.3632652255424773,
    "p": 0.0005332977801479901
  },
  "leaf_B": {
    "n": 37,
    "obs": 0.05769913204311897,
    "null_mean": 0.1117857003091028,
    "null_sd": 0.010434076337680549,
    "effect": 0.054086568265983834,
    "z": 5.1836469770363065,
    "p": 6.666222251849876e-05
  },
  "sheet_B": {
    "n": 37,
    "obs": 0.056743477027027034,
    "null_mean": 0.11083449170396607,
    "null_sd": 0.010528699014810627,
    "effect": 0.05409101467693904,
    "z": 5.137483235188857,
    "p": 6.666222251849876e-05
  },
  "leaf_focus_B": {
    "n": 37,
    "obs": 0.06977625746191093,
    "null_mean": 0.09386064589681309,
    "null_sd": 0.007464111266439494,
    "effect": 0.024084388434902154,
    "z": 3.2266920434575477,
    "p": 0.0007999466702219852
  },
  "leaf_plus_sheet_focus": {
    "n": 37,
    "obs": 0.055776605016361114,
    "null_mean": 0.08295677870147823,
    "null_sd": 0.008226302356488456,
    "effect": 0.027180173685117118,
    "z": 3.304057218815801,
    "p": 0.0007332844477034864
  },
  "leaf_plus_sheet_B": {
    "n": 37,
    "obs": 0.05687999077664607,
    "null_mean": 0.11126818763150507,
    "null_sd": 0.01051636637213985,
    "effect": 0.054388196854859,
    "z": 5.17176702772026,
    "p": 6.666222251849876e-05
  },
  "full_focus_B_multilevel": {
    "n": 37,
    "obs": 0.055989291806338395,
    "null_mean": 0.08155864744284062,
    "null_sd": 0.00827084321537787,
    "effect": 0.025569355636502228,
    "z": 3.091505300083728,
    "p": 0.0017998800079994668
  },
  "within_quire_only": {
    "n": 37,
    "obs": 0.056743477027027034,
    "null_mean": 0.11033829072162162,
    "null_sd": 0.010420571232452772,
    "effect": 0.05359481369459458,
    "z": 5.143174255906847,
    "p": 6.666222251849876e-05
  },
  "focus_only_shared": {
    "n": 37,
    "obs": 0.08897683783783789,
    "null_mean": 0.12315095062018021,
    "null_sd": 0.010721496062657949,
    "effect": 0.03417411278234232,
    "z": 3.1874388222151038,
    "p": 0.0023998400106659554
  },
  "background_only_shared": {
    "n": 37,
    "obs": 0.018224074324324466,
    "null_mean": 0.026057157712432482,
    "null_sd": 0.0021215231693398583,
    "effect": 0.007833083388108016,
    "z": 3.6921978988074824,
    "p": 0.00033331111259249385
  },
  "focus_background_correlations": {
    "all_leaves_D_sigma": -0.6194893410406686,
    "within_quire_D_sigma": -0.5574818036928545,
    "within_quire_D_logB": 0.17293414872426352,
    "leaf_sigma_logB": -0.2226781953054114,
    "between_sheets_D_sigma": -0.6997703185774966,
    "between_sheets_D_logB": 0.18110360444641374,
    "conjugate_delta_D_vs_delta_sigma": -0.18563491133144136
  },
  "crosswing": {
    "n": 37,
    "obs": 0.056743477027027034,
    "null_mean": 0.10332568350972973,
    "null_sd": 0.011549626715981545,
    "effect": 0.0465822064827027,
    "z": 4.033221819909174,
    "p": 0.00013332444503699753
  },
  "focus_B_matched_crosswing": {
    "n": 37,
    "obs": 0.056743477027027034,
    "null_mean": 0.08158322555990993,
    "null_sd": 0.008017182378734415,
    "effect": 0.0248397485328829,
    "z": 3.0983140160027243,
    "p": 6.666444451851606e-05
  },
  "focus_B_matched_crosswing_residual": {
    "n": 37,
    "obs": 0.06977625746191093,
    "null_mean": 0.08357948174789412,
    "null_sd": 0.007069073706078677,
    "effect": 0.013803224285983184,
    "z": 1.9526213560503451,
    "p": 0.023699210026332455
  },
  "matched_null_parameters": {
    "focus_scale": 0.11153114992913203,
    "B_scale": 0.022355568088802256,
    "temperature": 1.0,
    "conditioning_is_sensitivity_not_permutation_p": true
  },
  "fitted_background_components": {
    "B": {
      "observed_model_R2": 0.6297746383361025,
      "fitted_component_shared": {
        "n": 37,
        "obs": 0.013127540934158416,
        "null_mean": 0.01877002905114405,
        "null_sd": 0.0015282193077483968,
        "effect": 0.005642488116985636,
        "z": 3.692197898807469,
        "p": 0.00033331111259249385
      },
      "residual_shared": {
        "n": 37,
        "obs": 0.05769913204311897,
        "null_mean": 0.1117857003091028,
        "null_sd": 0.010434076337680549,
        "effect": 0.054086568265983834,
        "z": 5.1836469770363065,
        "p": 6.666222251849876e-05
      }
    },
    "sigma": {
      "observed_model_R2": 0.7369692272095713,
      "fitted_component_shared": {
        "n": 37,
        "obs": 0.041414682571374,
        "null_mean": 0.05732118214397597,
        "null_sd": 0.004990370156045151,
        "effect": 0.01590649957260197,
        "z": 3.187438822215106,
        "p": 0.0023998400106659554
      },
      "residual_shared": {
        "n": 37,
        "obs": 0.06977460967623834,
        "null_mean": 0.09381859858299814,
        "null_sd": 0.007465773084311858,
        "effect": 0.024043988906759794,
        "z": 3.2205625104363858,
        "p": 0.0007999466702219852
      }
    },
    "B_sigma": {
      "observed_model_R2": 0.7369728710773913,
      "fitted_component_shared": {
        "n": 37,
        "obs": 0.04137819112526,
        "null_mean": 0.05730311527509466,
        "null_sd": 0.005009288093411234,
        "effect": 0.01592492414983466,
        "z": 3.17907931284305,
        "p": 0.0024665022331844546
      },
      "residual_shared": {
        "n": 37,
        "obs": 0.06977625746191092,
        "null_mean": 0.09386064589681309,
        "null_sd": 0.007464111266439496,
        "effect": 0.024084388434902168,
        "z": 3.2266920434575486,
        "p": 0.0007999466702219852
      }
    }
  },
  "strict_single_panel": {
    "n": 33,
    "obs": 0.057293063636363634,
    "null_mean": 0.10809236480575757,
    "null_sd": 0.010140774326108356,
    "effect": 0.050799301169393934,
    "z": 5.009410478508181,
    "p": 4.999750012499375e-05
  },
  "oracle_outcome_matching_NOT_VALID_NULL": {
    "mean_absolute_gap": 0.046254520270270265,
    "observed": 0.056743477027027034
  },
  "leave_one_sheet_out": {
    "least_z": [
      {
        "sheet": "G:49-56",
        "n": 36,
        "obs": 0.0576206375,
        "null_mean": 0.10174314854629629,
        "null_sd": 0.010011068893311433,
        "effect": 0.04412251104629629,
        "z": 4.407372630886128,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "G:50-55",
        "n": 36,
        "obs": 0.05830277222222223,
        "null_mean": 0.11170753442129633,
        "null_sd": 0.011505245830241536,
        "effect": 0.0534047621990741,
        "z": 4.641774977002203,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "G:51-54",
        "n": 36,
        "obs": 0.05503383888888889,
        "null_mean": 0.10631581272916667,
        "null_sd": 0.010966576805095165,
        "effect": 0.05128197384027778,
        "z": 4.6762061445146434,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "D:28-29",
        "n": 36,
        "obs": 0.057512066666666674,
        "null_mean": 0.10842642968981482,
        "null_sd": 0.010674299411448158,
        "effect": 0.05091436302314815,
        "z": 4.76980840246458,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "E:35-38",
        "n": 36,
        "obs": 0.05690186805555556,
        "null_mean": 0.10513546673148148,
        "null_sd": 0.010103139874334121,
        "effect": 0.04823359867592592,
        "z": 4.774119657440148,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "F:42-47",
        "n": 36,
        "obs": 0.05626843611111111,
        "null_mean": 0.10423230606944446,
        "null_sd": 0.009989065503215565,
        "effect": 0.04796386995833335,
        "z": 4.801637344643838,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "Q:93-96",
        "n": 35,
        "obs": 0.05700755285714286,
        "null_mean": 0.11210189468809524,
        "null_sd": 0.011390582222421487,
        "effect": 0.05509434183095238,
        "z": 4.836832811101034,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "Q:94-95",
        "n": 35,
        "obs": 0.05700755285714286,
        "null_mean": 0.11210189468809524,
        "null_sd": 0.011390582222421487,
        "effect": 0.05509434183095238,
        "z": 4.836832811101034,
        "p": 0.0008326394671107411
      }
    ],
    "greatest_z": [
      {
        "sheet": "T:105-114",
        "n": 36,
        "obs": 0.05422513611111111,
        "null_mean": 0.11025720763657408,
        "null_sd": 0.010723687922178322,
        "effect": 0.056032071525462974,
        "z": 5.22507480002095,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "T:104-115",
        "n": 36,
        "obs": 0.05354920833333334,
        "null_mean": 0.1096966015949074,
        "null_sd": 0.010715888919065546,
        "effect": 0.056147393261574065,
        "z": 5.239639351027378,
        "p": 0.0008326394671107411
      },
      {
        "sheet": "F:44-45",
        "n": 36,
        "obs": 0.05345480694444445,
        "null_mean": 0.109385543125,
        "null_sd": 0.010667777490880225,
        "effect": 0.05593073618055555,
        "z": 5.242960516224693,
        "p": 0.0008326394671107411
      }
    ],
    "minimum_z": 4.407372630886128
  },
  "greedy_minimum_removals_to_below_2SD": {
    "history": [
      {
        "removed": [
          "C:17-24"
        ],
        "n": 36,
        "obs": 0.058198141666666675,
        "null_mean": 0.10531658097619048,
        "null_sd": 0.010055198672162582,
        "effect": 0.04711843930952381,
        "z": 4.6859779548632225,
        "p": 0.002849002849002849
      },
      {
        "removed": [
          "C:17-24",
          "G:49-56"
        ],
        "n": 35,
        "obs": 0.059141925714285726,
        "null_mean": 0.09638231315918368,
        "null_sd": 0.009803397938038111,
        "effect": 0.03724038744489795,
        "z": 3.798722410359548,
        "p": 0.002849002849002849
      },
      {
        "removed": [
          "C:17-24",
          "G:49-56",
          "E:35-38"
        ],
        "n": 34,
        "obs": 0.059380176470588235,
        "null_mean": 0.09124796205882353,
        "null_sd": 0.009544471729592201,
        "effect": 0.031867785588235296,
        "z": 3.3388736947515567,
        "p": 0.002849002849002849
      },
      {
        "removed": [
          "C:17-24",
          "G:49-56",
          "E:35-38",
          "F:42-47"
        ],
        "n": 33,
        "obs": 0.05894184999999999,
        "null_mean": 0.08461678909090908,
        "null_sd": 0.008550803583892179,
        "effect": 0.025674939090909094,
        "z": 3.00263464585656,
        "p": 0.002849002849002849
      },
      {
        "removed": [
          "C:17-24",
          "G:49-56",
          "E:35-38",
          "F:42-47",
          "D:28-29"
        ],
        "n": 32,
        "obs": 0.0598752125,
        "null_mean": 0.08135173861607142,
        "null_sd": 0.008708406264426947,
        "effect": 0.021476526116071426,
        "z": 2.4661833019666406,
        "p": 0.014245014245014245
      },
      {
        "removed": [
          "C:17-24",
          "G:49-56",
          "E:35-38",
          "F:42-47",
          "D:28-29",
          "O:87-90"
        ],
        "n": 30,
        "obs": 0.06038045166666666,
        "null_mean": 0.07443973288571427,
        "null_sd": 0.007186063920951095,
        "effect": 0.014059281219047613,
        "z": 1.9564648149117534,
        "p": 0.03133903133903134
      }
    ],
    "threshold_reached": true,
    "selection_post_hoc": true
  },
  "familywise_340": {
    "permutations": 20000,
    "hits": 0,
    "empirical_p": 4.999750012499375e-05,
    "bonferroni_340_upper": 0.016999150042497874,
    "null_mean": 0.11033722283527046,
    "null_sd": 0.010329821952946662,
    "effect": 0.05359374580824343,
    "z": 5.188254555825659,
    "selection_family_340_approx_not_independent": true
  }
}

## Planted-signal power, independent simulation
{
  "sheet_plants": [
    {
      "plant_sheet_sd_log": 0.03,
      "latent_focus_correlation": 0,
      "n_sim": 600,
      "raw_power_z3": 0.01,
      "leaf_focus_power_z3": 0.013333333333333334,
      "sheet_focus_power_z3": 0.006666666666666667,
      "all_focus_B_power_z3": 0.011666666666666667,
      "raw_power_z2": 0.075,
      "leaf_focus_power_z2": 0.06833333333333333,
      "sheet_focus_power_z2": 0.06333333333333334,
      "all_focus_B_power_z2": 0.07666666666666666
    },
    {
      "plant_sheet_sd_log": 0.06,
      "latent_focus_correlation": 0,
      "n_sim": 600,
      "raw_power_z3": 0.06166666666666667,
      "leaf_focus_power_z3": 0.06,
      "sheet_focus_power_z3": 0.05333333333333334,
      "all_focus_B_power_z3": 0.065,
      "raw_power_z2": 0.2966666666666667,
      "leaf_focus_power_z2": 0.3,
      "sheet_focus_power_z2": 0.25833333333333336,
      "all_focus_B_power_z2": 0.2866666666666667
    },
    {
      "plant_sheet_sd_log": 0.09,
      "latent_focus_correlation": 0,
      "n_sim": 600,
      "raw_power_z3": 0.3383333333333333,
      "leaf_focus_power_z3": 0.3233333333333333,
      "sheet_focus_power_z3": 0.305,
      "all_focus_B_power_z3": 0.33,
      "raw_power_z2": 0.7483333333333333,
      "leaf_focus_power_z2": 0.7433333333333333,
      "sheet_focus_power_z2": 0.71,
      "all_focus_B_power_z2": 0.7266666666666667
    },
    {
      "plant_sheet_sd_log": 0.12,
      "latent_focus_correlation": 0,
      "n_sim": 600,
      "raw_power_z3": 0.755,
      "leaf_focus_power_z3": 0.7483333333333333,
      "sheet_focus_power_z3": 0.7166666666666667,
      "all_focus_B_power_z3": 0.7466666666666667,
      "raw_power_z2": 0.9566666666666667,
      "leaf_focus_power_z2": 0.9566666666666667,
      "sheet_focus_power_z2": 0.94,
      "all_focus_B_power_z2": 0.95
    },
    {
      "plant_sheet_sd_log": 0.06,
      "latent_focus_correlation": 0.8,
      "n_sim": 600,
      "raw_power_z3": 0.025,
      "leaf_focus_power_z3": 0.006666666666666667,
      "sheet_focus_power_z3": 0.008333333333333333,
      "all_focus_B_power_z3": 0.01,
      "raw_power_z2": 0.16666666666666666,
      "leaf_focus_power_z2": 0.06166666666666667,
      "sheet_focus_power_z2": 0.06,
      "all_focus_B_power_z2": 0.075
    },
    {
      "plant_sheet_sd_log": 0.09,
      "latent_focus_correlation": 0.8,
      "n_sim": 600,
      "raw_power_z3": 0.11666666666666667,
      "leaf_focus_power_z3": 0.03166666666666667,
      "sheet_focus_power_z3": 0.03,
      "all_focus_B_power_z3": 0.041666666666666664,
      "raw_power_z2": 0.45166666666666666,
      "leaf_focus_power_z2": 0.18166666666666667,
      "sheet_focus_power_z2": 0.17,
      "all_focus_B_power_z2": 0.18666666666666668
    },
    {
      "plant_sheet_sd_log": 0.12,
      "latent_focus_correlation": 0.8,
      "n_sim": 600,
      "raw_power_z3": 0.4583333333333333,
      "leaf_focus_power_z3": 0.10333333333333333,
      "sheet_focus_power_z3": 0.12,
      "all_focus_B_power_z3": 0.12833333333333333,
      "raw_power_z2": 0.7866666666666666,
      "leaf_focus_power_z2": 0.3983333333333333,
      "sheet_focus_power_z2": 0.40166666666666667,
      "all_focus_B_power_z2": 0.4533333333333333
    }
  ],
  "facing_plants": [
    {
      "contraction": 0,
      "n_sim": 650,
      "power_z3": 0.0,
      "power_z2": 0.016923076923076923,
      "median_effect": -0.0006658256567901172,
      "median_null_sd": 0.012997526019688697,
      "median_z": -0.0507042353534916,
      "mean_unmodified_gap": 0.13377966222222223,
      "calibration": "Quire-shuffled null pages, paired contraction, random same-quire page pairs"
    },
    {
      "contraction": 0.25,
      "n_sim": 650,
      "power_z3": 0.036923076923076927,
      "power_z2": 0.34,
      "median_effect": 0.019153697439506165,
      "median_null_sd": 0.011906377756388429,
      "median_z": 1.600228810322859,
      "mean_unmodified_gap": 0.13377966222222223,
      "calibration": "Quire-shuffled null pages, paired contraction, random same-quire page pairs"
    },
    {
      "contraction": 0.5,
      "n_sim": 650,
      "power_z3": 0.8076923076923077,
      "power_z2": 0.9830769230769231,
      "median_effect": 0.04058033554135804,
      "median_null_sd": 0.01111112278035195,
      "median_z": 3.6422487354056825,
      "mean_unmodified_gap": 0.13377966222222223,
      "calibration": "Quire-shuffled null pages, paired contraction, random same-quire page pairs"
    },
    {
      "contraction": 0.75,
      "n_sim": 650,
      "power_z3": 1.0,
      "power_z2": 1.0,
      "median_effect": 0.06348623413271604,
      "median_null_sd": 0.010801830309071368,
      "median_z": 5.910211192111581,
      "mean_unmodified_gap": 0.13377966222222223,
      "calibration": "Quire-shuffled null pages, paired contraction, random same-quire page pairs"
    },
    {
      "contraction": 1.0,
      "n_sim": 650,
      "power_z3": 1.0,
      "power_z2": 1.0,
      "median_effect": 0.09104590547530864,
      "median_null_sd": 0.010913153866949793,
      "median_z": 8.35586254830302,
      "mean_unmodified_gap": 0.13377966222222223,
      "calibration": "Quire-shuffled null pages, paired contraction, random same-quire page pairs"
    }
  ]
}

## Quire scope and same-sheet-face geometry (independent)
{
  "scope": {
    "herbal": {
      "n_sheets": 22,
      "observed": 0.049076959090909075,
      "null_mean": 0.12314888948060607,
      "null_sd": 0.013955718117607251,
      "effect": 0.07407193038969699,
      "z": 5.307640192033117,
      "p": 3.333222225925803e-05,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "F",
        "G"
      ]
    },
    "balneo_stars": {
      "n_sheets": 11,
      "observed": 0.07372527272727274,
      "null_mean": 0.07829221495242425,
      "null_sd": 0.012439589903666929,
      "effect": 0.004566942225151513,
      "z": 0.3671296449897657,
      "p": 0.3352554914836172,
      "qui": [
        "M",
        "T"
      ]
    },
    "later": {
      "n_sheets": 4,
      "observed": 0.05220938750000001,
      "null_mean": 0.12671609386750002,
      "null_sd": 0.046902184680384235,
      "effect": 0.07450670636750001,
      "z": 1.5885551360821948,
      "p": 0.11026299123362554,
      "qui": [
        "O",
        "Q"
      ]
    },
    "ex_herbal": {
      "n_sheets": 15,
      "observed": 0.06798770333333333,
      "null_mean": 0.09126143867422223,
      "null_sd": 0.015444840040966787,
      "effect": 0.023273735340888904,
      "z": 1.5068939062597153,
      "p": 0.0866304456518116,
      "qui": [
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_A": {
      "n_sheets": 35,
      "observed": 0.057290765714285714,
      "null_mean": 0.11395860974971429,
      "null_sd": 0.011085389825035215,
      "effect": 0.05666784403542858,
      "z": 5.1119396728340645,
      "p": 0.0001999600079984003,
      "qui": [
        "C",
        "D",
        "E",
        "F",
        "G",
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_C": {
      "n_sheets": 33,
      "observed": 0.059528478787878786,
      "null_mean": 0.10461983828666667,
      "null_sd": 0.010307150447345398,
      "effect": 0.045091359498787884,
      "z": 4.37476485175407,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "D",
        "E",
        "F",
        "G",
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_D": {
      "n_sheets": 33,
      "observed": 0.058423004545454536,
      "null_mean": 0.11395987664,
      "null_sd": 0.011281844716234096,
      "effect": 0.05553687209454546,
      "z": 4.922676520678419,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "C",
        "E",
        "F",
        "G",
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_E": {
      "n_sheets": 33,
      "observed": 0.05721481969696969,
      "null_mean": 0.10857508686848484,
      "null_sd": 0.010895230332076584,
      "effect": 0.05136026717151515,
      "z": 4.714013894713697,
      "p": 0.0003999200159968006,
      "qui": [
        "A",
        "C",
        "D",
        "F",
        "G",
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_F": {
      "n_sheets": 33,
      "observed": 0.0553884606060606,
      "null_mean": 0.10769125033333335,
      "null_sd": 0.01093035886935367,
      "effect": 0.05230278972727275,
      "z": 4.785093550214376,
      "p": 0.0003999200159968006,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "G",
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_G": {
      "n_sheets": 33,
      "observed": 0.05769317575757575,
      "null_mean": 0.10299306793212122,
      "null_sd": 0.010366655489835447,
      "effect": 0.04529989217454547,
      "z": 4.369769229715622,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "F",
        "M",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_M": {
      "n_sheets": 32,
      "observed": 0.060414090625,
      "null_mean": 0.11983989561000001,
      "null_sd": 0.011742661928210071,
      "effect": 0.05942580498500001,
      "z": 5.060675794662706,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "F",
        "G",
        "O",
        "Q",
        "T"
      ]
    },
    "exclude_O": {
      "n_sheets": 35,
      "observed": 0.05699758285714285,
      "null_mean": 0.10612741276914285,
      "null_sd": 0.00952040633196493,
      "effect": 0.049129829912,
      "z": 5.160476160250193,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "F",
        "G",
        "M",
        "Q",
        "T"
      ]
    },
    "exclude_Q": {
      "n_sheets": 35,
      "observed": 0.05700755285714286,
      "null_mean": 0.11264017354971428,
      "null_sd": 0.010806285401040604,
      "effect": 0.055632620692571425,
      "z": 5.148172441125256,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "F",
        "G",
        "M",
        "O",
        "T"
      ]
    },
    "exclude_T": {
      "n_sheets": 31,
      "observed": 0.04692865806451613,
      "null_mean": 0.11185101616193546,
      "null_sd": 0.011494580414637702,
      "effect": 0.06492235809741934,
      "z": 5.6480842062529195,
      "p": 0.0001999600079984003,
      "qui": [
        "A",
        "C",
        "D",
        "E",
        "F",
        "G",
        "M",
        "O",
        "Q"
      ]
    }
  },
  "same_sheet_face_geometry": {
    "D_same_face_vs_opposite_face": {
      "n_complete_sheets": 22,
      "same_face_gap": 0.06942054772727273,
      "comparator_gap": 0.09450389318181819,
      "effect": 0.02505478522927273,
      "null_mean": 2.8560225272727272e-05,
      "null_sd": 0.0108978290260387,
      "z": 2.299062058085894,
      "p_two_sided": 0.01495970080598388,
      "note": "paired sign-flip of which physical-side comparison is smaller"
    },
    "D_same_face_vs_same_leaf": {
      "n_complete_sheets": 22,
      "same_face_gap": 0.06942054772727273,
      "comparator_gap": 0.08071933863636362,
      "effect": 0.01131738474036363,
      "null_mean": -1.859383127272728e-05,
      "null_sd": 0.012685521895434069,
      "z": 0.8921497147418999,
      "p_two_sided": 0.3869322613547729,
      "note": "paired sign-flip of which physical-side comparison is smaller"
    },
    "logB_same_face_vs_opposite_face": {
      "n_complete_sheets": 22,
      "same_face_gap": 0.021220284090909095,
      "comparator_gap": 0.019691474999999983,
      "effect": -0.0015305735780000221,
      "null_mean": 1.7644870909088684e-06,
      "null_sd": 0.0021722136745233028,
      "z": -0.704614650000263,
      "p_two_sided": 0.5165896682066359,
      "note": "paired sign-flip of which physical-side comparison is smaller"
    },
    "logB_same_face_vs_same_leaf": {
      "n_complete_sheets": 22,
      "same_face_gap": 0.021220284090909095,
      "comparator_gap": 0.0186567659090908,
      "effect": -0.00257551311127284,
      "null_mean": 1.1994929454545249e-05,
      "null_sd": 0.0029314027077846374,
      "z": -0.8785940957321571,
      "p_two_sided": 0.4062918741625168,
      "note": "paired sign-flip of which physical-side comparison is smaller"
    },
    "sigma_same_face_vs_opposite_face": {
      "n_complete_sheets": 22,
      "same_face_gap": 0.08341330454545454,
      "comparator_gap": 0.17351306363636362,
      "effect": 0.09003534383290912,
      "null_mean": 6.441525800000017e-05,
      "null_sd": 0.027858819203361213,
      "z": 3.231843502615007,
      "p_two_sided": 9.99980000399992e-05,
      "note": "paired sign-flip of which physical-side comparison is smaller"
    },
    "sigma_same_face_vs_same_leaf": {
      "n_complete_sheets": 22,
      "same_face_gap": 0.08341330454545454,
      "comparator_gap": 0.17746439545454543,
      "effect": 0.09394851180436366,
      "null_mean": 0.00010257910472727272,
      "null_sd": 0.027993823521786303,
      "z": 3.35604429781619,
      "p_two_sided": 3.999920001599968e-05,
      "note": "paired sign-flip of which physical-side comparison is smaller"
    }
  },
  "complete_sheets": 22
}
