from pathlib import Path
import pickle, numpy as np,pandas as pd,os,json
P=Path(__file__).parent;R=P/'results'
a=pickle.load(open(R/'01_baseline_word_rederivation.pkl','rb'))
b=pickle.load(open(R/'02_focus_skin_matched_nulls_influence.pkl','rb'))
L=a['leaves'];idx=a['pairs'];raw_idx=a['null_indexes']['random_repair'][:1000];cov_idx=b['matched_indexes'][:1000];D=L.D.to_numpy();sg=L.sigma.to_numpy();bg=L.logB.to_numpy();Q={x:g.index.to_numpy() for x,g in L.groupby('quire')};
FE=np.column_stack([np.ones(len(L)),pd.get_dummies(L.quire,drop_first=True,dtype=float).values]);X=np.column_stack([FE,sg,bg]);S=L.groupby('bifolium',sort=False).sigma.transform('mean').values
X4=np.column_stack([FE,sg,S,bg,L.groupby('bifolium',sort=False).logB.transform('mean')]);
RNG=np.random.default_rng(20261114)

def res(y,X):return y-X@np.linalg.lstsq(X,y,rcond=None)[0]
def z(v,pm):
 o=np.mean(abs(v[idx[:,0]]-v[idx[:,1]]));nl=np.abs(v[pm[:,:,0]]-v[pm[:,:,1]]).mean(axis=1);return (nl.mean()-o)/nl.std()
configs=[(.09,0),(.12,0),(.15,0),(.18,0),(.21,0),(.12,.8),(.18,.8),(.24,.8)]
out=[]
for tau,r in configs:
 vv=[]
 for j in range(450):
  vals=D.copy()
  for q,ix in Q.items():vals[ix]=RNG.permutation(vals[ix])
  correlated=(S-S.mean())/S.std();ind=np.repeat(RNG.normal(size=len(idx)),2)
  vals+=tau*(r*correlated+(1-r*r)**0.5*ind)
  clean=res(vals,X);clean4=res(vals,X4)
  vv.append([z(vals,raw_idx),z(vals,cov_idx),z(clean,raw_idx),z(clean,cov_idx),z(clean4,cov_idx)])
 vv=np.array(vv)
 out.append({'tau':tau,'corr_focus_latent':r,'n':len(vv),'columns':['raw_unmatched','raw_matched','leaf_focus_B_unmatched','leaf_focus_B_matched','full_multilevel_matched'],'power3':np.mean(vv>=3,axis=0).round(4).tolist(),'power2':np.mean(vv>=2,axis=0).round(4).tolist()})
path=R/'06_matched_power.pkl';tmp=path.with_suffix('.tmp')
with tmp.open('wb') as f:pickle.dump(out,f);f.flush();os.fsync(f.fileno())
os.replace(tmp,path)
(R/'06_matched_power.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
