# VMS Explorer — iOS / macOS App

Native Apple wrapper around the VMS Corpus Explorer. Runs on iPhone, iPad, and Mac (via Catalyst).

## Quick Start

### Option A: Open the Xcode project directly
1. Open `VMSExplorer.xcodeproj` in **Xcode 15+**
2. Select your signing team (Xcode → Target → Signing & Capabilities)
3. Choose a device or simulator
4. Run (⌘R)

### Option B: Create from scratch (if pbxproj gives trouble)
1. Xcode → File → New → Project → **App** (SwiftUI, Swift)
2. Product name: `VMSExplorer`, bundle ID: `com.vms.explorer`
3. Delete the default ContentView.swift
4. Drag in: `VMSExplorerApp.swift`, `ContentView.swift`, `Info.plist`
5. Drag in the `Resources` folder (check "Create folder references")
6. Drag in `Assets.xcassets`
7. Build settings: set `INFOPLIST_FILE` to `VMSExplorer/Info.plist`
8. Run

## What's Inside

```
VMSExplorer/
├── VMSExplorerApp.swift    # @main entry point (SwiftUI)
├── ContentView.swift       # WKWebView wrapper (~60 lines)
├── Info.plist              # App config, document access permission
├── Assets.xcassets/
│   ├── AppIcon.appiconset/ # 1024x1024 app icon
│   └── LaunchBG.colorset/  # Dark launch screen background
└── Resources/
    ├── index.html          # Full app (4.1MB, self-contained)
    └── mammoth.min.js      # .docx text extraction
```

## Features

- **iPhone + iPad + Mac** — Universal binary, Mac Catalyst enabled
- **Full offline** — everything in the app bundle
- **File upload** — iOS 16+ handles `<input type="file">` natively via document picker
- **Dark theme** — launch screen and status bar match the app
- **All orientations** — portrait + landscape on all devices

## Requirements

- **Xcode 15+**
- **iOS 16.0+** (covers 95%+ of active devices)
- **macOS 13+** (via Catalyst)
- Swift 5.0

## Mac Catalyst

The project has `SUPPORTS_MACCATALYST = YES` enabled, so it builds natively for Mac:
- Xcode → Target → General → check "Mac (Designed for iPad)"
- Or change destination to "My Mac (Designed for iPad)"
- Run — it opens as a native Mac window

## Updating the Web App

Replace `Resources/index.html` and rebuild. That's it.

## PWA Alternative (no Xcode needed)

If you don't want to build a native app:
1. Open the HTML file in Safari on iPhone/iPad
2. Tap Share → "Add to Home Screen"
3. Done — runs fullscreen with an app icon
