import SwiftUI
import WebKit

struct ContentView: View {
    var body: some View {
        WebView()
            .ignoresSafeArea()
            .statusBarHidden(false)
    }
}

struct WebView: UIViewRepresentable {
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        
        // Allow file access for uploaded documents
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.031, green: 0.031, blue: 0.047, alpha: 1) // #08080C
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        // Allow zoom
        webView.scrollView.maximumZoomScale = 3.0
        webView.scrollView.minimumZoomScale = 1.0
        
        // Load from bundle
        if let htmlURL = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Resources") {
            webView.loadFileURL(htmlURL, allowingReadAccessTo: htmlURL.deletingLastPathComponent())
        }
        
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        
        // Handle file upload picker
        func webView(_ webView: WKWebView,
                     runOpenPanelWith parameters: WKOpenPanelParameters,
                     initiateByFrame frame: WKFrameInfo,
                     completionHandler: @escaping ([URL]?) -> Void) {
            completionHandler(nil) // macOS only — iOS uses document picker below
        }
    }
}

// MARK: - Document Picker for file uploads on iOS
// WKWebView on iOS 16+ handles <input type="file"> natively via UIDocumentPickerViewController.
// No extra code needed — the system presents the file picker automatically.
// Supported: .txt, .docx files as configured in the HTML accept attribute.
