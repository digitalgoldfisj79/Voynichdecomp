# VMS Explorer — Android WebView App

A native Android wrapper around the VMS Corpus Explorer web app. Runs entirely offline with the full Voynich Manuscript corpus (37,465 tokens), live statistics engine, and file upload comparison.

## Building

1. Open this folder in **Android Studio** (Hedgehog 2023.1+ recommended)
2. Let Gradle sync (downloads dependencies automatically)
3. Connect a device or start an emulator (API 24+ / Android 7.0+)
4. Run → the app loads from `assets/index.html`

## What's Inside

```
app/src/main/
├── assets/
│   ├── index.html       # Full app (4.1MB, self-contained)
│   └── mammoth.min.js   # .docx text extraction
├── java/.../
│   └── MainActivity.kt  # WebView wrapper (~100 lines)
├── res/
│   ├── layout/          # Single FrameLayout
│   ├── mipmap-*/        # Launcher icons
│   └── values/          # Dark theme matching the app
└── AndroidManifest.xml
```

## Features

- **Full offline operation** — everything bundled in assets
- **File upload** — Android file picker integration via WebChromeClient
- **RTL support** — Arabic, Hebrew, and Greek text with proper rendering
- **Dark theme** — status bar and nav bar match the app's colour scheme
- **Back navigation** — hardware back button works within the app

## Customisation

To update the web app, simply replace `assets/index.html` and rebuild.

The WebView has JavaScript enabled, DOM storage, file access, and zoom support. The `onShowFileChooser` override handles the HTML `<input type="file">` for the upload panel, supporting .txt and .docx files.

## Min SDK

- **minSdk 24** (Android 7.0 Nougat) — covers 97%+ of active devices
- WebView supports ES6, Unicode property escapes, and CSS Grid
