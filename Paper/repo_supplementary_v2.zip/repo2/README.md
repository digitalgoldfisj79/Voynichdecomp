# VMS Grammar Paper — Supplementary Repository

Reproducibility materials for:

> **Bozzard, E.** (2026). A Formal Grammar for Voynich Manuscript Script: Four-Slot Decomposition and Information-Theoretic Analysis.

## Repository Structure

```
├── src/                              # Working source code
│   ├── p70c_full.py                  # P70-C-FULL constraint layer module (681 lines)
│   │                                 #   - P70C_Full class: validation, generation, scoring
│   │                                 #   - Transition grammar (prev_sfx → prefix)
│   │                                 #   - Paragraph markers, quire metadata
│   │                                 #   - Full suffix access (VP+terminal)
│   │                                 #   - build_p70c_full() builder function
│   └── p70c_connect.py               # Connection analysis script (498 lines)
│                                     #   - 4-axis information budget derivation
│                                     #   - Cross-validation of axes
│                                     #   - Transition matrix construction
│                                     #   - Suffix decomposition validation
│
├── data/                             # All data files
│   ├── enriched_records.pkl          # Ground truth: 37,465 tokens, fully decomposed
│   ├── p70_rules_canonical.json      # Character grammar: 210 rules, 92.96% coverage
│   ├── p70c_full_layer.pkl           # Pre-built P70C_Full layer (5,172 quads, 6,750 quints)
│   ├── p70c_full_spec_v1.json        # JSON export: quint table + transitions + examples
│   ├── transition_lookup.json        # 8×8 P(prefix | prev_sfx_fam) matrix
│   └── voynich_section_map.json      # Folio → section mapping (9 sections)
│
├── docs/
│   └── PGCS_OPERATIONAL_GUIDE.md     # Architecture documentation
│
├── supplementary/                    # Extended methods (S1–S6)
│   ├── S1_PGCS_Grammar.md           # Full grammar specification
│   ├── S2_Information_Budget.md      # 5-axis entropy decomposition derivation
│   ├── S3_Semantic_Tests.md          # Positive-controlled falsification tests
│   ├── S4_Generator_Validation.md    # Bowern-Gaskell benchmark validation
│   ├── S5_Cross_Validation.md        # Red team, held-out generalisation
│   └── S6_Mechanism_Exclusions.md    # Formal mechanism exclusion proofs
│
├── LITERATURE_REVIEW_ANNOTATED.md    # 30-reference citation audit
└── LICENSE                           # CC-BY 4.0 (data), MIT (code)
```

## Quick Start

### Load the pre-built constraint layer

```python
import pickle, sys
sys.path.insert(0, 'src')
from p70c_full import P70C_Full

with open('data/p70c_full_layer.pkl', 'rb') as f:
    layer = pickle.load(f)

layer.summary()
# P70-C-FULL Layer Summary
#   Quads (no pos):   5,172
#   Quints (w/ pos):  6,750
#   Tokens: 37,465
#   Transitions: 8 prev_sfx values
```

### Validate a token

```python
layer.is_valid('qo', 'k', 'ee', 'Y', 'MID')   # → True
layer.tier('qo', 'k', 'ee', 'Y', 'MID')        # → 'T2'
layer.probability('qo', 'k', 'ee', 'Y', 'MID')  # → 0.0023
```

### Generate VMS-like text

```python
import random
line = layer.generate_line(8, section='Herbal-A', first_line=True, min_tier='T2')
print(' '.join(tok for tok, quint in line))
```

### Query transitions

```python
layer.transition_dist('Y')
# {'qo': 0.2596, 'o': 0.1984, '∅': 0.1934, 'ch': 0.13, ...}
```

### Reproduce the information budget (Table 1 in paper)

```bash
cd src
python p70c_connect.py
# Requires enriched_records.pkl in ../data/
```

## Data Layer Hierarchy

```
                     Abstraction
                         ↑
  p70c_full_layer.pkl   SLOT COMBINATIONS    6,750 quints, 292× compression
                               |              + transitions, paragraph markers
                               |              + quire metadata, full suffix
                               |
  p70_rules_canonical.json  CHARACTERS       210 rules, char adjacency
                               |
  enriched_records.pkl      RAW DATA         37,465 tokens, 4-slot decomposition
                         ↓
                      Concreteness
```

See `docs/PGCS_OPERATIONAL_GUIDE.md` for complete usage documentation.

## Key Results Summary

| Metric | Value |
|--------|-------|
| Tokens decomposed | 37,465 |
| PGCS grammar coverage | 100% (0 exceptions) |
| Observed quads (P,G,mc,SF) | 5,172 of 4,158 possible → 127× compression |
| Observed quints (+position) | 6,750 → 292× compression |
| P70 character rules | 210 (92.96% char coverage) |
| Information budget: grammar | 2.634 bits (28.87%) |
| Information budget: content | 6.490 bits (71.13%) |
| Generator Bowern-Gaskell pass rate | 83.7% (7/8 core metrics) |
| Semantic tests passed | 0/5 (all negative, positive controls pass) |
| Mechanisms excluded | 4 (mono-substitution, word encryption, IID, Cardan grille) |

## GitHub Repository

Upstream code and additional artifacts:
**https://github.com/digitalgoldfisj79/Voynichdecomp**

Includes: `cipher_diagnostics.py`, `clean_latin.py`, `p70_section_realign.py`,
`v3d_p70_test.py`, `v3d_p70_fingerprint_results.md`, `antidotarium_latin.txt`,
`VMS_formal_grammar.pdf`

## Dependencies

```
numpy
```

No other dependencies required. The module uses only numpy and Python standard library
(pickle, json, math, random, collections).

## Transcription Source

All analyses use the ZLZI transcription (ZL_ivtff_2b) from René Zandbergen's
voynich.nu, comprising 37,465 tokens across 7,598 types.

## Citation

```bibtex
@article{bozzard2026grammar,
  author  = {Bozzard, Edward},
  title   = {A Formal Grammar for {Voynich} Manuscript Script:
             Four-Slot Decomposition and Information-Theoretic Analysis},
  year    = {2026},
  note    = {Manuscript in preparation}
}
```

## License

- **Code** (`src/`): MIT License
- **Data and Supplementary** (`data/`, `supplementary/`): CC-BY 4.0
