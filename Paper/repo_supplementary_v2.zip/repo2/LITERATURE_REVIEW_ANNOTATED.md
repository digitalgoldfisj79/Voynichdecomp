# Annotated Reference List with Insertion Points

## Paper: "A Productive Grammar Without Recoverable Semantics"

### CURRENT REFERENCES (8 — retain all)
1. Bowern & Lindemann 2021 — Linguistic benchmarks
2. Currier 1976 — Foundational statistical observations  
3. Greshko 2025 — Naibbe cipher
4. Rugg 2004 — Cardan grille hoax hypothesis
5. Stolfi 2005 — Word structure analysis
6. Tiltman 1967 — Early structural observations
7. Timm & Schinner 2020 — Linguistic classification
8. Tucker & Janick 2016 — Plant identifications

---

### REFERENCES TO ADD (22 new, total → 30)

#### A. VMS Provenance & Dating
**[INSERT §1.1, sentence 1: after "over five centuries"]**

9. **d'Imperio, M. E. (1978).** *The Voynich Manuscript: An Elegant Enigma.* Fort Meade, MD: NSA.
   - *The foundational comprehensive reference. Needed for historical framing and any discussion of prior approaches. Currently cited nowhere despite being the standard reference work.*
   - INSERT: §1.2 as general background citation.

10. **Hodgins, G. (2012).** Measuring the age of the Voynich Manuscript. Presentation at the Voynich MS Centenary, Villa Mondragone, 11 May 2012.
    - *Radiocarbon dating of vellum to 1404–1438 (mean 1421 ± 8.5 years). Essential for the dating claim in the Abstract.*
    - INSERT: Abstract line "c. 1404–1438" needs this citation.

#### B. Information Theory Methodology
**[INSERT §3.1 and §3.3: entropy and MI calculations need foundational citations]**

11. **Shannon, C. E. (1948).** A mathematical theory of communication. *Bell System Technical Journal*, 27(3), 379–423.
    - *Foundational. The paper uses Shannon entropy, conditional entropy, and MI throughout. Currently uncited.*
    - INSERT: §3.1, first mention of "entropy" or "information."

12. **Cover, T. M. and Thomas, J. A. (2006).** *Elements of Information Theory.* 2nd ed. Hoboken, NJ: Wiley.
    - *Standard reference for MI, conditional entropy, chain rule. Reviewers will expect this.*
    - INSERT: §3.1 or §3.3, alongside the chain rule invocation.

#### C. Zipf's Law
**[INSERT §1.1: "Word-frequency distributions follow Zipf's law"]**

13. **Zipf, G. K. (1949).** *Human Behavior and the Principle of Least Effort.* Cambridge, MA: Addison-Wesley.
    - *The paper claims Zipf R² = 0.915. The originator needs citing.*
    - INSERT: §1.1, parenthetical after "Zipf's law."

14. **Piantadosi, S. T. (2014).** Zipf's word frequency law in natural language: A critical review and future directions. *Psychonomic Bulletin & Review*, 21(5), 1112–1130.
    - *Modern critical review. Useful because Zipf fit alone is insufficient to distinguish language from structured pseudo-text.*
    - INSERT: §4.4 or §5.1, where generator matches Zipf but lacks semantics.

#### D. VMS Statistical Studies (currently underrepresented)
**[INSERT §1.2: "The linguistic tradition"]**

15. **Montemurro, M. A. and Zanette, D. H. (2013).** Keywords and co-occurrence patterns in the Voynich Manuscript: An information-theoretic analysis. *PLOS ONE*, 8(6), e66344.
    - *Major information-theoretic study of VMS. Found section-specific keyword distributions. Your paper's §4.3 Test 1 (section classification) directly extends and reinterprets their finding. MUST CITE.*
    - INSERT: §1.2 (linguistic tradition), §4.3 (section classification reinterpretation).

16. **Landini, G. (2001).** Evidence of linguistic structure in the Voynich Manuscript using spectral analysis. *Cryptologia*, 25(4), 275–295.
    - *First rigorous frequency analysis. Spectral methods showing language-like structure.*
    - INSERT: §1.2 (linguistic tradition).

17. **Schinner, A. (2007).** The Voynich Manuscript: Evidence of the hoax hypothesis. *Cryptologia*, 31(2), 95–107.
    - *Tests Rugg's hypothesis with additional statistical methods. Complements your §4.4 Cardan grille exclusion.*
    - INSERT: §4.4 (Cardan grille paragraph) or §1.2 (hoax tradition).

18. **Bennett, W. R. (1976).** *Scientific and Engineering Problem-Solving with the Computer.* Englewood Cliffs, NJ: Prentice-Hall.
    - *Early computational analysis of VMS. One of the first to apply character frequency analysis.*
    - INSERT: §1.2 (linguistic tradition), alongside Currier.

19. **Reddy, S. and Knight, K. (2011).** What we know about the Voynich Manuscript. In *Proceedings of the 5th ACL-HLT Workshop on Language Technology for Cultural Heritage*.
    - *Computational linguistics survey. Useful meta-reference for the state of the field.*
    - INSERT: §1.2, as a survey citation.

20. **Matlach, V., Janečková, B. A., and Dostál, D. (2022).** The Voynich Manuscript: Symbol roles revisited. *PLOS ONE*, 17(1), e0260948.
    - *Recent symbol-role analysis. Directly relevant to your PGCS slot assignments.*
    - INSERT: §2.2 (PGCS model context) or §1.2.

#### E. Codicology & Paleography
**[INSERT §1.2 or Acknowledgments]**

21. **Fagin Davis, L. (2020).** How many scribes? Paleographic assessment of the Voynich Manuscript. *Yale University Library Gazette*, Occasional Paper.
    - *Paleographic hand assignments. Your cross-quire analysis in Bozzard 2026b validates her findings statistically. Important cross-reference.*
    - INSERT: §3.3 (quire axis discussion) or §5.2 footnote.

22. **Zandbergen, R. (2024).** Voynich Manuscript transcription and analysis. *Online resource.* http://voynich.nu
    - *The ZLZI transcription you use. Currently acknowledged but not formally cited.*
    - INSERT: §2.1 (corpus description), as a formal reference.

#### F. Methodology — Morphological Analysis
**[INSERT §2.2: PGCS decomposition needs methodological framing]**

23. **Beesley, K. R. and Karttunen, L. (2003).** *Finite State Morphology.* Stanford, CA: CSLI Publications.
    - *Standard reference for finite-state approaches to morphological decomposition. Your P70 grammar is essentially a finite-state system.*
    - INSERT: §2.2 or §2.3, when discussing rule-based grammar.

24. **Jurafsky, D. and Martin, J. H. (2024).** *Speech and Language Processing.* 3rd ed. Draft. https://web.stanford.edu/~jurafsky/slp3/
    - *Standard NLP textbook. Provides context for entropy, n-gram models, morphological parsing.*
    - INSERT: §3.1 (methodological context for entropy calculations).

#### G. Mutual Information in Text Analysis
**[INSERT §3.2–3.3: MI methodology]**

25. **Church, K. W. and Hanks, P. (1990).** Word association norms, mutual information, and lexicography. *Computational Linguistics*, 16(1), 22–29.
    - *Foundational paper on MI for word association. Your word-to-word MI (0.45 bits) directly echoes this methodology.*
    - INSERT: §4.3 Test 5 (word-to-word MI).

#### H. Medieval Notation Systems & Historical Context
**[INSERT §5.1: "Like musical notation or pharmaceutical abbreviation systems"]**

26. **Clemens, R. and Graham, T. (2007).** *Introduction to Manuscript Studies.* Ithaca, NY: Cornell University Press.
    - *Standard reference for manuscript analysis methodology.*
    - INSERT: §2.1 or §5.1.

27. **Eamon, W. (1994).** *Science and the Secrets of Nature: Books of Secrets in Medieval and Early Modern Culture.* Princeton, NJ: Princeton University Press.
    - *Historical context for medieval notation and secrecy traditions. Supports the "notation system" interpretation in §5.1.*
    - INSERT: §5.1 (historical framing of notation systems).

#### I. Statistical Methodology
**[INSERT §4.3: multiple comparison correction, permutation testing]**

28. **Efron, B. and Tibshirani, R. J. (1993).** *An Introduction to the Bootstrap.* Boca Raton, FL: Chapman & Hall/CRC.
    - *Bootstrap methodology used for confidence intervals throughout.*
    - INSERT: §3.3 or §4.3 (methodology note).

#### J. Self-Citation (companion papers)
**[Already referenced as Bozzard 2026a, 2026b, 2026c — need formal entries]**

29. **Bozzard, E. (2026a).** Two-level information architecture in the Voynich Manuscript. *Working paper.*
    - *Paper 2: character vs word entropy architecture.*

30. **Bozzard, E. (2026b).** Cross-quire lexical clustering in the Voynich Manuscript: Statistical codicology of production units. *Working paper.*
    - *Paper 1: codicological analysis, cross-quire clustering, Fagin Davis validation.*

---

### INSERTION POINT SUMMARY

| Paper Section | New Citations Needed | Refs |
|---------------|---------------------|------|
| Abstract (dating) | Radiocarbon dating | [10] |
| §1.1 (paradox) | Zipf, d'Imperio | [9, 13] |
| §1.2 (previous approaches) | Montemurro, Landini, Bennett, Reddy, Schinner, Matlach, d'Imperio | [9, 15, 16, 17, 18, 19, 20] |
| §2.1 (corpus) | Zandbergen formal cite | [22] |
| §2.2 (PGCS model) | Beesley & Karttunen, Matlach | [20, 23] |
| §3.1 (entropy) | Shannon, Cover & Thomas, Jurafsky | [11, 12, 24] |
| §3.2 (across-word) | Church & Hanks (MI methodology) | [25] |
| §3.3 (information budget) | Cover & Thomas (chain rule), Efron (bootstrap) | [12, 28] |
| §4.3 (semantic tests) | Montemurro (reinterpretation), Piantadosi | [14, 15] |
| §4.4 (mechanism exclusions) | Schinner, Piantadosi | [14, 17] |
| §5.1 (what kind of system) | Eamon, Clemens | [26, 27] |
| §5.2 (constraint space) | Fagin Davis | [21] |
| §5.3 (limitations) | Zandbergen (transcription) | [22] |
| Self-citations | Bozzard 2026a, 2026b | [29, 30] |
